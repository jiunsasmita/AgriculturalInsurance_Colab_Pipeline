"""
06_exploratory_analysis.py

Tujuan
------
Fase 4: Exploratory Analysis atas master_research_dataset_v1.xlsx --
statistik deskriptif, matriks korelasi, tren nasional per tahun, dan
ranking provinsi. Semua hasil disimpan sebagai file (PNG + Excel) supaya
bisa langsung dilampirkan ke manuskrip atau laporan.

Cara pakai
----------
    python 06_exploratory_analysis.py --input /path/ke/master_research_dataset_v1.xlsx

Input
-----
Sheet "Data" dari file output Script 05, dengan kolom:
    Provinsi, Tahun, Luas_Panen_Ha, Produktivitas_KuHa, Produksi_Ton,
    Rainfall_mm, Temperature_C, Humidity_pct

Output (di outputs/eda/)
------------------------
eda_summary_report.xlsx
    Sheet "Deskriptif"       : statistik ringkas tiap variabel
    Sheet "Korelasi"         : matriks korelasi Pearson
    Sheet "Tren_Tahunan"     : rata-rata nasional per tahun
    Sheet "Ranking_Provinsi" : rata-rata tiap provinsi, terurut produktivitas

01_tren_produktivitas_nasional.png
02_ranking_provinsi.png
03_scatter_rainfall_produktivitas.png
04_heatmap_korelasi.png
05_boxplot_produktivitas_per_provinsi.png
"""

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # render ke file, tidak butuh display
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

BASE_DIR = Path(__file__).resolve().parent.parent
OUT_DIR = BASE_DIR / "outputs" / "eda"
OUT_DIR.mkdir(parents=True, exist_ok=True)

CLIMATE_COLS = ["Rainfall_mm", "Temperature_C", "Humidity_pct"]
NUMERIC_COLS = ["Luas_Panen_Ha", "Produktivitas_KuHa", "Produksi_Ton"] + CLIMATE_COLS

sns.set_style("whitegrid")
plt.rcParams["font.size"] = 10
plt.rcParams["figure.dpi"] = 150


def load_data(input_path: str) -> pd.DataFrame:
    df = pd.read_excel(input_path, sheet_name="Data")
    missing = df[NUMERIC_COLS].isna().sum()
    if missing.sum() > 0:
        print("[PERINGATAN] Masih ada nilai kosong sebelum analisis:")
        print(missing[missing > 0])
    else:
        print(f"Data lengkap: {len(df)} baris, {df['Provinsi'].nunique()} provinsi, "
              f"tahun {df['Tahun'].min()}-{df['Tahun'].max()}.")
    return df


def descriptive_stats(df: pd.DataFrame) -> pd.DataFrame:
    desc = df[NUMERIC_COLS].describe().T
    desc["skewness"] = df[NUMERIC_COLS].skew()
    desc["cv_pct"] = (desc["std"] / desc["mean"] * 100).round(1)  # koefisien variasi
    return desc.round(2)


def correlation_matrix(df: pd.DataFrame) -> pd.DataFrame:
    cols = ["Produktivitas_KuHa", "Luas_Panen_Ha"] + CLIMATE_COLS
    return df[cols].corr(method="pearson").round(3)


def yearly_trend(df: pd.DataFrame) -> pd.DataFrame:
    return (
        df.groupby("Tahun")
        .agg(
            Produktivitas_rata2=("Produktivitas_KuHa", "mean"),
            Rainfall_rata2=("Rainfall_mm", "mean"),
            Suhu_rata2=("Temperature_C", "mean"),
            Kelembapan_rata2=("Humidity_pct", "mean"),
            Total_Produksi_Ton=("Produksi_Ton", "sum"),
        )
        .round(2)
    )


def province_ranking(df: pd.DataFrame) -> pd.DataFrame:
    ranking = (
        df.groupby("Provinsi")
        .agg(
            Produktivitas_rata2=("Produktivitas_KuHa", "mean"),
            Produktivitas_std=("Produktivitas_KuHa", "std"),
            Rainfall_rata2=("Rainfall_mm", "mean"),
            Suhu_rata2=("Temperature_C", "mean"),
            Kelembapan_rata2=("Humidity_pct", "mean"),
        )
        .round(2)
        .sort_values("Produktivitas_rata2", ascending=False)
    )
    ranking.insert(0, "Peringkat", range(1, len(ranking) + 1))
    return ranking


# --------------------------- VISUALISASI ---------------------------

def plot_national_trend(yearly: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(yearly.index, yearly["Produktivitas_rata2"], marker="o",
            color="#2a78d6", linewidth=2)
    ax.set_xlabel("Tahun")
    ax.set_ylabel("Produktivitas rata-rata nasional (ku/ha)")
    ax.set_title("Tren produktivitas padi nasional, 2018-2025")
    ax.set_xticks(yearly.index)
    fig.tight_layout()
    fig.savefig(OUT_DIR / "01_tren_produktivitas_nasional.png")
    plt.close(fig)


def plot_province_ranking(ranking: pd.DataFrame, n: int = 10):
    top = ranking.head(n)
    bottom = ranking.tail(n)
    combined = pd.concat([top, bottom]).sort_values("Produktivitas_rata2")

    fig, ax = plt.subplots(figsize=(7, 6))
    colors = ["#d95926" if v < 45 else "#199e70" for v in combined["Produktivitas_rata2"]]
    ax.barh(combined.index, combined["Produktivitas_rata2"], color=colors)
    ax.set_xlabel("Produktivitas rata-rata 2018-2025 (ku/ha)")
    ax.set_title(f"{n} provinsi tertinggi & terendah berdasarkan produktivitas")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "02_ranking_provinsi.png")
    plt.close(fig)


def plot_rainfall_scatter(df: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.scatter(df["Rainfall_mm"], df["Produktivitas_KuHa"], alpha=0.5,
               color="#2a78d6", s=25)
    z = np.polyfit(df["Rainfall_mm"], df["Produktivitas_KuHa"], 1)
    x_line = np.linspace(df["Rainfall_mm"].min(), df["Rainfall_mm"].max(), 100)
    ax.plot(x_line, np.poly1d(z)(x_line), color="#d95926", linewidth=2,
            label=f"Garis tren (slope={z[0]:.4f})")
    r = df["Rainfall_mm"].corr(df["Produktivitas_KuHa"])
    ax.set_xlabel("Curah hujan tahunan (mm)")
    ax.set_ylabel("Produktivitas (ku/ha)")
    ax.set_title(f"Curah hujan vs produktivitas (r = {r:.2f}, n={len(df)})")
    ax.legend()
    fig.tight_layout()
    fig.savefig(OUT_DIR / "03_scatter_rainfall_produktivitas.png")
    plt.close(fig)


def plot_correlation_heatmap(corr: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="RdBu_r", center=0,
                vmin=-1, vmax=1, square=True, ax=ax,
                cbar_kws={"label": "Koefisien korelasi Pearson"})
    ax.set_title("Matriks korelasi variabel iklim & pertanian")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "04_heatmap_korelasi.png")
    plt.close(fig)


def plot_boxplot_by_region(df: pd.DataFrame):
    order = (
        df.groupby("Provinsi")["Produktivitas_KuHa"]
        .median()
        .sort_values(ascending=False)
        .index
    )
    fig, ax = plt.subplots(figsize=(8, 10))
    sns.boxplot(data=df, y="Provinsi", x="Produktivitas_KuHa", order=order,
                ax=ax, color="#85B7EB")
    ax.set_xlabel("Produktivitas (ku/ha)")
    ax.set_ylabel("")
    ax.set_title("Sebaran produktivitas tiap provinsi (2018-2025)")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "05_boxplot_produktivitas_per_provinsi.png")
    plt.close(fig)


def main(input_path: str):
    df = load_data(input_path)

    desc = descriptive_stats(df)
    corr = correlation_matrix(df)
    yearly = yearly_trend(df)
    ranking = province_ranking(df)

    out_path = OUT_DIR / "eda_summary_report.xlsx"
    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        desc.to_excel(writer, sheet_name="Deskriptif")
        corr.to_excel(writer, sheet_name="Korelasi")
        yearly.to_excel(writer, sheet_name="Tren_Tahunan")
        ranking.to_excel(writer, sheet_name="Ranking_Provinsi")

    plot_national_trend(yearly)
    plot_province_ranking(ranking)
    plot_rainfall_scatter(df)
    plot_correlation_heatmap(corr)
    plot_boxplot_by_region(df)

    print("\n=== Statistik deskriptif ===")
    print(desc[["mean", "std", "min", "max", "cv_pct"]].to_string())
    print("\n=== Korelasi dengan Produktivitas ===")
    print(corr["Produktivitas_KuHa"].drop("Produktivitas_KuHa").to_string())
    print(f"\nDisimpan ke: {out_path}")
    print(f"Grafik (5 file PNG) disimpan di: {OUT_DIR}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Exploratory Data Analysis (Fase 4)")
    parser.add_argument("--input", required=True,
                         help="Path ke master_research_dataset_v1.xlsx (Script 05)")
    args = parser.parse_args()
    main(args.input)
