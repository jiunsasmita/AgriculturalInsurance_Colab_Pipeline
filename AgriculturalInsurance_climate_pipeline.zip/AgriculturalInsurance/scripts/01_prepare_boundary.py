"""
01_prepare_boundary.py

Tujuan
------
Memuat shapefile batas provinsi Indonesia (BIG / BPS / GADM), memvalidasi
geometrinya, dan mencocokkan nama provinsi di shapefile dengan nama baku
yang dipakai pada dataset BPS Anda (lihat utils.BPS_PROVINCE_NAMES).

Cara pakai
----------
    python 01_prepare_boundary.py --input /path/ke/shapefile_provinsi.shp \
                                   --name-field NAMOBJ

--name-field adalah nama kolom di shapefile yang berisi nama provinsi.
Untuk shapefile BIG biasanya "NAMOBJ" atau "WADMPR".
Untuk GADM level-1 biasanya "NAME_1".
Jika tidak yakin, jalankan dulu tanpa --name-field: script akan
menampilkan semua nama kolom yang tersedia.

Output
------
data/shapefile/provinces_clean.geojson
    Shapefile yang sudah distandarkan: kolom "Provinsi" berisi nama baku
    BPS, siap dipakai di Script 02 & 03 (CHIRPS, NASA POWER).

data/shapefile/boundary_validation_report.csv
    Laporan pencocokan nama, luas wilayah, dan validitas geometri per provinsi.
"""

import argparse
import sys
from pathlib import Path

import geopandas as gpd
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from utils import match_province, BPS_PROVINCE_NAMES  # noqa: E402

OUT_DIR = Path(__file__).resolve().parent.parent / "data" / "shapefile"
OUT_DIR.mkdir(parents=True, exist_ok=True)


def main(input_path: str, name_field: str | None):
    print(f"Membaca shapefile: {input_path}")
    gdf = gpd.read_file(input_path)
    print(f"Jumlah fitur (provinsi mentah): {len(gdf)}")
    print(f"CRS asli: {gdf.crs}")
    print(f"Kolom tersedia: {list(gdf.columns)}")

    if name_field is None:
        print(
            "\n[BERHENTI] --name-field belum ditentukan.\n"
            "Silakan pilih salah satu kolom di atas yang berisi nama provinsi,\n"
            "lalu jalankan ulang dengan --name-field <nama_kolom>."
        )
        sys.exit(1)

    if name_field not in gdf.columns:
        print(f"[ERROR] Kolom '{name_field}' tidak ditemukan di shapefile.")
        sys.exit(1)

    # --- Standarkan CRS ke WGS84 (dipakai CHIRPS & NASA POWER) ---
    if gdf.crs is None:
        print("[PERINGATAN] Shapefile tidak punya CRS. Mengasumsikan EPSG:4326.")
        gdf = gdf.set_crs(epsg=4326)
    elif gdf.crs.to_epsg() != 4326:
        print(f"Mengonversi CRS dari {gdf.crs} ke EPSG:4326 ...")
        gdf = gdf.to_crs(epsg=4326)

    # --- Perbaiki geometri tidak valid (self-intersection dll) ---
    n_invalid = (~gdf.geometry.is_valid).sum()
    if n_invalid > 0:
        print(f"Memperbaiki {n_invalid} geometri tidak valid (buffer(0)) ...")
        gdf["geometry"] = gdf.geometry.buffer(0)

    # --- Cocokkan nama provinsi ---
    gdf["Provinsi"] = gdf[name_field].apply(match_province)
    unmatched = gdf[gdf["Provinsi"].isna()]
    if len(unmatched) > 0:
        print(
            f"\n[PERINGATAN] {len(unmatched)} fitur tidak cocok dengan nama BPS:"
        )
        for raw in unmatched[name_field].tolist():
            print(f"   - '{raw}'  (tambahkan alias di scripts/utils.py jika ini nama provinsi)")

    # --- Gabungkan provinsi yang dipecah jadi beberapa fitur (mis. akibat
    #     rekonsolidasi Papua) menjadi satu geometri per nama Provinsi ---
    matched = gdf.dropna(subset=["Provinsi"])
    dissolved = matched.dissolve(by="Provinsi", as_index=False)
    dissolved = dissolved[["Provinsi", "geometry"]]

    # --- Cek kelengkapan terhadap 35 provinsi (versi konsolidasi Papua) ---
    found = set(dissolved["Provinsi"])
    expected = set(BPS_PROVINCE_NAMES)
    missing = expected - found
    extra = found - expected

    report_rows = []
    for _, row in dissolved.iterrows():
        area_km2 = (
            row.geometry.area * (111.32 ** 2)
        )  # aproksimasi kasar derajat->km, cukup untuk QC, bukan analisis luas resmi
        report_rows.append(
            {
                "Provinsi": row["Provinsi"],
                "geometry_valid": row.geometry.is_valid,
                "approx_area_km2": round(area_km2, 1),
            }
        )
    report = pd.DataFrame(report_rows).sort_values("Provinsi")
    report.to_csv(OUT_DIR / "boundary_validation_report.csv", index=False)

    dissolved.to_file(OUT_DIR / "provinces_clean.geojson", driver="GeoJSON")

    print(f"\nProvinsi cocok    : {len(found)}")
    print(f"Provinsi hilang   : {sorted(missing) if missing else 'tidak ada'}")
    print(f"Nama tak dikenal  : {sorted(extra) if extra else 'tidak ada'}")
    print(f"\nDisimpan ke:\n  {OUT_DIR / 'provinces_clean.geojson'}")
    print(f"  {OUT_DIR / 'boundary_validation_report.csv'}")

    if missing:
        print(
            "\n[TINDAK LANJUT] Ada provinsi yang hilang dari shapefile Anda.\n"
            "Cek boundary_validation_report.csv dan nama kolom sumber shapefile;\n"
            "kemungkinan perlu menambah alias di scripts/utils.py."
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Validasi & standarkan shapefile provinsi")
    parser.add_argument("--input", required=True, help="Path ke file shapefile (.shp) atau GeoJSON")
    parser.add_argument("--name-field", default=None, help="Nama kolom berisi nama provinsi")
    args = parser.parse_args()
    main(args.input, args.name_field)
