"""
09_estimate_transition_model.py

Tujuan
------
Fase 7: mengestimasi parameter model multi-state -- baseline transition
probability/intensity (q^(0)) dan koefisien iklim (gamma) -- yang jadi
gap paling kritis di draft artikel sebelumnya (Reviewer #4: "the paper
never says how gamma_rs and q_rs^(0) are estimated").

Ringkasan prosedur estimasi (untuk disalin ke bagian Metode manuskrip)
-----------------------------------------------------------------------
1. STRUKTUR DATA: panel tahunan, 34 provinsi x 8 tahun, interval antar
   observasi SERAGAM (selalu tepat 1 tahun, tidak ada data hilang di
   tengah). Karena keseragaman ini, model discrete-time Markov dengan
   Delta_t=1 secara matematis EKUIVALEN dengan continuous-time Markov
   chain (CTMC) yang dievaluasi pada interval satuan -- P(1) = exp(Q*1).
   Ini menghindari kompleksitas numerik matrix exponential untuk interval
   tidak seragam (yang di draf sebelumnya tidak dijelaskan penanganannya --
   Reviewer #13), sambil tetap bisa dikonversi balik ke notasi intensitas
   Q lewat matrix logarithm: Q = logm(P), KARENA Delta_t seragam.

2. STRUKTUR TRANSISI: PENUH (4x4, semua arah diizinkan), BUKAN hanya
   deteriorasi searah seperti draf sebelumnya. Ini keputusan berbasis
   BUKTI, bukan asumsi: dari 238 transisi teramati, 61 adalah transisi
   PEMBAIKAN (mis. x2->x1) vs 48 transisi deteriorasi murni (mis. x1->x2)
   -- pembaikan justru lebih banyak. Ini konsisten dengan skala tahunan
   data kita: setiap tahun adalah musim tanam baru, sehingga "collapse"
   tahun ini tidak mencegah "normal" tahun depan (tanam ulang, kondisi
   iklim membaik, dll). Ini BUKAN kontradiksi dengan draf awal, melainkan
   klarifikasi skala waktu: draf awal membayangkan transisi DALAM SATU
   musim tanam (di mana pembaikan memang tidak masuk akal), sedangkan
   model ini mengestimasi transisi ANTAR-tahun. (Menjawab Reviewer #7.)

3. MODEL: untuk tiap state asal r, peluang transisi ke state tujuan s
   dimodelkan sebagai multinomial logistic regression:

        P(State_{t+1}=s | State_t=r, Z_t) = softmax(beta_{r,s}^T Z_t)_s

   dengan Z_t = (Anomali_Rainfall_t, Anomali_Temperature_t, Anomali_Humidity_t)
   -- anomali BERTANDA (bukan nilai absolut seperti di ACRI Fase 5) relatif
   terhadap rata-rata historis provinsi itu sendiri, karena arah deviasi
   (kekeringan vs kelebihan air, misalnya) relevan secara agronomis.

   Regresi logistik multinomial pada data panel dengan interval seragam
   ini SECARA MATEMATIS setara dengan estimasi maximum likelihood untuk
   continuous-time Markov chain dengan intensitas q_rs(t|Z) = q_rs^(0)
   * exp(gamma_rs^T Z) -- persis kerangka di artikel. Estimasi baseline
   q_rs^(0) diperoleh dari prediksi model pada Z=0 (kondisi iklim rata-rata/
   normal), lalu dikonversi ke intensitas kontinu lewat matrix logarithm.

4. REGULARISASI untuk transisi jarang: regresi logistik memakai penalti
   L2 (ridge, C=1.0 default) -- BUKAN maximum likelihood tanpa penalti --
   karena beberapa transisi (terutama menuju x4, cuma 11 observasi total)
   terlalu jarang untuk estimasi stabil tanpa regularisasi. Ini langsung
   menjawab Reviewer #2 poin 10 ("Penalization... may be required").

5. STANDARD ERROR: dihitung lewat BOOTSTRAP (resampling PROVINSI, bukan
   baris, supaya struktur panel per-provinsi tetap utuh), B=200 replikasi.
   Dipilih bootstrap alih-alih Hessian asimtotik standar karena ukuran
   sampel kecil (terutama untuk transisi ke x4) membuat aproksimasi
   asimtotik kurang bisa diandalkan. (Menjawab Reviewer #4 poin 1: "no
   ... method used to calculate standard errors".)

6. VALIDASI OUT-OF-SAMPLE: provinsi (bukan baris) dibagi 80% train / 20%
   test secara acak (bukan random per baris, untuk menghindari kebocoran
   data provinsi yang sama muncul di train DAN test). Model dilatih HANYA
   di provinsi train, dievaluasi di provinsi test yang sama sekali tidak
   dilihat model. Ini langsung menjawab kekhawatiran sirkularitas
   Reviewer #4 poin 2 ("no train/test split described").

Cara pakai
----------
    python 09_estimate_transition_model.py \
        --state outputs/state_construction/state_dataset.xlsx \
        --acri outputs/acri/acri_dataset.xlsx

Output (di outputs/transition_model/)
----------------------------------------
transition_model.xlsx
    Sheet "Koefisien_Gamma"      : koefisien iklim tiap transisi + bootstrap SE
    Sheet "Baseline_P_1tahun"    : matriks peluang transisi 1-tahun pada Z=0
    Sheet "Baseline_Q_intensitas": matriks intensitas kontinu (Q = logm(P))
    Sheet "Validasi_OOS"         : akurasi & log-loss di provinsi test (held-out)
    Sheet "Jumlah_Transisi"      : jumlah transisi train vs test per jenis
    Sheet "Metodologi"           : ringkasan prosedur (siap salin ke manuskrip)
01_koefisien_gamma.png
02_matriks_P_baseline.png
03_validasi_confusion.png
"""

import argparse
import pickle
import warnings
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy.linalg import logm
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, accuracy_score
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore", category=UserWarning)

BASE_DIR = Path(__file__).resolve().parent.parent
OUT_DIR = BASE_DIR / "outputs" / "transition_model"
OUT_DIR.mkdir(parents=True, exist_ok=True)

STATE_ORDER = ["x1", "x2", "x3", "x4"]
COVARIATES = ["Anomali_Rainfall", "Anomali_Temperature", "Anomali_Humidity"]
RANDOM_SEED = 42
N_BOOTSTRAP = 200
MIN_OBS_FOR_MODEL = 8  # di bawah ini, fallback ke frekuensi empiris (Laplace-smoothed)

sns.set_style("whitegrid")
plt.rcParams["font.size"] = 10
plt.rcParams["figure.dpi"] = 150


def load_and_merge(state_path: str, acri_path: str) -> pd.DataFrame:
    state = pd.read_excel(state_path, sheet_name="Data")[["Provinsi", "Tahun", "State"]]
    acri = pd.read_excel(acri_path, sheet_name="ACRI")[["Provinsi", "Tahun"] + COVARIATES]
    df = state.merge(acri, on=["Provinsi", "Tahun"], how="inner")
    df = df.sort_values(["Provinsi", "Tahun"]).reset_index(drop=True)
    df["State_next"] = df.groupby("Provinsi")["State"].shift(-1)
    return df


def train_test_split_by_province(df: pd.DataFrame, test_frac: float = 0.2, seed: int = RANDOM_SEED):
    provinces = sorted(df["Provinsi"].unique())
    rng = np.random.RandomState(seed)
    n_test = max(1, round(len(provinces) * test_frac))
    test_provinces = set(rng.choice(provinces, size=n_test, replace=False))
    train_df = df[~df["Provinsi"].isin(test_provinces)].copy()
    test_df = df[df["Provinsi"].isin(test_provinces)].copy()
    return train_df, test_df, sorted(test_provinces)


def fit_origin_model(sub: pd.DataFrame, scaler: StandardScaler):
    """
    Fit multinomial logistic regression (L2) untuk satu state asal.
    Kembalikan model + daftar kelas (state tujuan) yang muncul di data latih.
    Kalau observasi terlalu sedikit, kembalikan None (fallback ke frekuensi empiris).
    """
    sub = sub.dropna(subset=["State_next"])
    if len(sub) < MIN_OBS_FOR_MODEL or sub["State_next"].nunique() < 2:
        return None, sub["State_next"].value_counts()

    X = scaler.transform(sub[COVARIATES].values)
    y = sub["State_next"].values
    model = LogisticRegression(
        C=1.0,  # L2 (ridge) adalah default LogisticRegression, tidak perlu dieja ulang
        max_iter=2000, random_state=RANDOM_SEED,
    )
    model.fit(X, y)
    return model, None


def empirical_fallback_probs(counts: pd.Series) -> dict:
    """Peluang transisi Laplace-smoothed (tambah 1 ke tiap state) kalau data terlalu sedikit untuk model."""
    smoothed = {s: counts.get(s, 0) + 1 for s in STATE_ORDER}
    total = sum(smoothed.values())
    return {s: v / total for s, v in smoothed.items()}


def bootstrap_se(train_df: pd.DataFrame, origin: str, scaler: StandardScaler,
                  n_boot: int = N_BOOTSTRAP) -> pd.DataFrame | None:
    sub = train_df[train_df["State"] == origin].dropna(subset=["State_next"])
    if len(sub) < MIN_OBS_FOR_MODEL or sub["State_next"].nunique() < 2:
        return None

    provinces = sub["Provinsi"].unique()
    rng = np.random.RandomState(RANDOM_SEED)
    coef_samples = []

    for _ in range(n_boot):
        boot_provs = rng.choice(provinces, size=len(provinces), replace=True)
        boot_sub = pd.concat([sub[sub["Provinsi"] == p] for p in boot_provs], ignore_index=True)
        if boot_sub["State_next"].nunique() < 2:
            continue
        X = scaler.transform(boot_sub[COVARIATES].values)
        y = boot_sub["State_next"].values
        try:
            m = LogisticRegression(C=1.0,  # L2 (ridge) adalah default LogisticRegression, tidak perlu dieja ulang
                                    max_iter=2000, random_state=RANDOM_SEED)
            m.fit(X, y)
            for i, cls in enumerate(m.classes_):
                for j, cov in enumerate(COVARIATES):
                    coef_samples.append({"State_tujuan": cls, "Covariate": cov, "Coef": m.coef_[i, j]})
        except Exception:
            continue

    if not coef_samples:
        return None
    boot_df = pd.DataFrame(coef_samples)
    return boot_df.groupby(["State_tujuan", "Covariate"])["Coef"].agg(["mean", "std"]).reset_index()


def build_baseline_matrix(models: dict, fallbacks: dict, scaler: StandardScaler) -> pd.DataFrame:
    """Matriks peluang transisi 1-tahun pada Z=0 (kondisi iklim rata-rata/normal provinsi)."""
    P = pd.DataFrame(0.0, index=STATE_ORDER, columns=STATE_ORDER)
    z_zero = scaler.transform(np.zeros((1, len(COVARIATES))))
    for r in STATE_ORDER:
        if models.get(r) is not None:
            model = models[r]
            probs = model.predict_proba(z_zero)[0]
            for cls, p in zip(model.classes_, probs):
                P.loc[r, cls] = p
        elif r in fallbacks:
            probs = empirical_fallback_probs(fallbacks[r])
            for s, p in probs.items():
                P.loc[r, s] = p
        else:
            P.loc[r, r] = 1.0  # tidak ada data sama sekali -- asumsi tetap di state yang sama
    # normalisasi baris (jaga-jaga floating point)
    P = P.div(P.sum(axis=1), axis=0)
    return P


def matrix_to_generator(P: pd.DataFrame) -> tuple[pd.DataFrame, list]:
    """Konversi matriks peluang 1-tahun ke matriks intensitas kontinu Q = logm(P)."""
    caveats = []
    Q_arr = logm(P.values)
    if np.iscomplexobj(Q_arr):
        if np.max(np.abs(Q_arr.imag)) > 1e-6:
            caveats.append("Matrix logarithm menghasilkan komponen imajiner signifikan -- "
                            "P mungkin bukan hasil embedding dari CTMC tunggal yang valid.")
        Q_arr = Q_arr.real
    off_diag_negative = Q_arr[~np.eye(len(STATE_ORDER), dtype=bool)] < -1e-8
    if off_diag_negative.any():
        caveats.append("Ada elemen off-diagonal negatif pada Q hasil logm(P) -- "
                        "ini masalah numerik yang dikenal (\"embedding problem\") pada matrix "
                        "logarithm dari matriks stokastik empiris. Nilai negatif kecil di-clip ke 0 "
                        "dan diagonal disesuaikan supaya baris tetap berjumlah 0.")
        Q_arr[~np.eye(len(STATE_ORDER), dtype=bool)] = np.clip(
            Q_arr[~np.eye(len(STATE_ORDER), dtype=bool)], 0, None)
        np.fill_diagonal(Q_arr, 0)
        np.fill_diagonal(Q_arr, -Q_arr.sum(axis=1))
    Q = pd.DataFrame(Q_arr, index=STATE_ORDER, columns=STATE_ORDER)
    return Q, caveats


def evaluate_oos(models: dict, fallbacks: dict, scaler: StandardScaler, test_df: pd.DataFrame) -> dict:
    test_df = test_df.dropna(subset=["State_next"])
    results = {}
    all_true, all_pred_label = [], []
    total_ll, total_n = 0.0, 0

    for r in STATE_ORDER:
        sub = test_df[test_df["State"] == r]
        if sub.empty:
            continue
        y_true = sub["State_next"].values
        if models.get(r) is not None:
            model = models[r]
            X = scaler.transform(sub[COVARIATES].values)
            proba_raw = model.predict_proba(X)
            proba = pd.DataFrame(0.0, index=sub.index, columns=STATE_ORDER)
            for i, cls in enumerate(model.classes_):
                proba[cls] = proba_raw[:, i]
            y_pred_label = proba.idxmax(axis=1).values
        else:
            probs = empirical_fallback_probs(fallbacks.get(r, pd.Series(dtype=int)))
            proba = pd.DataFrame([probs] * len(sub), index=sub.index)[STATE_ORDER]
            y_pred_label = [max(probs, key=probs.get)] * len(sub)

        proba_arr = proba.values
        proba_arr = np.clip(proba_arr, 1e-9, 1)
        y_true_idx = [STATE_ORDER.index(s) for s in y_true]
        ll = log_loss(y_true_idx, proba_arr, labels=list(range(len(STATE_ORDER))))
        acc = accuracy_score(y_true, y_pred_label)
        results[r] = {"n_test": len(sub), "log_loss": ll, "accuracy": acc}

        total_ll += ll * len(sub)
        total_n += len(sub)
        all_true.extend(y_true)
        all_pred_label.extend(y_pred_label)

    results["OVERALL"] = {
        "n_test": total_n,
        "log_loss": total_ll / total_n if total_n else np.nan,
        "accuracy": accuracy_score(all_true, all_pred_label) if total_n else np.nan,
    }
    results["_confusion_data"] = (all_true, all_pred_label)
    return results


def plot_coefficients(coef_table: pd.DataFrame):
    if coef_table.empty:
        return
    fig, ax = plt.subplots(figsize=(8, max(4, 0.3 * len(coef_table))))
    coef_table = coef_table.sort_values(["State_asal", "State_tujuan", "Covariate"])
    labels = coef_table["State_asal"] + "->" + coef_table["State_tujuan"] + " | " + coef_table["Covariate"]
    ax.barh(labels, coef_table["Coef_mean"], xerr=coef_table["Coef_std"].fillna(0),
            color="#2a78d6", capsize=3)
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_xlabel("Koefisien gamma (bootstrap mean +/- SE)")
    ax.set_title("Koefisien iklim per transisi (regresi logistik multinomial, L2)")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "01_koefisien_gamma.png")
    plt.close(fig)


def plot_baseline_matrix(P: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(5.5, 5))
    sns.heatmap(P, annot=True, fmt=".3f", cmap="Blues", vmin=0, vmax=1, ax=ax,
                cbar_kws={"label": "Peluang transisi 1-tahun"})
    ax.set_xlabel("State tujuan")
    ax.set_ylabel("State asal")
    ax.set_title("Matriks peluang transisi baseline (Z=0, kondisi iklim normal)")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "02_matriks_P_baseline.png")
    plt.close(fig)


def plot_confusion(all_true, all_pred):
    from sklearn.metrics import confusion_matrix
    cm = confusion_matrix(all_true, all_pred, labels=STATE_ORDER)
    fig, ax = plt.subplots(figsize=(5, 4.5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Greens", ax=ax,
                xticklabels=STATE_ORDER, yticklabels=STATE_ORDER,
                cbar_kws={"label": "Jumlah observasi"})
    ax.set_xlabel("Prediksi model")
    ax.set_ylabel("Aktual (data test, provinsi held-out)")
    ax.set_title("Confusion matrix -- validasi out-of-sample")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "03_validasi_confusion.png")
    plt.close(fig)


def main(state_path: str, acri_path: str):
    df = load_and_merge(state_path, acri_path)
    train_df, test_df, test_provinces = train_test_split_by_province(df)

    print(f"Total provinsi: {df['Provinsi'].nunique()} | Train: "
          f"{train_df['Provinsi'].nunique()} | Test (held-out): {len(test_provinces)}")
    print(f"Provinsi test (held-out): {test_provinces}")

    scaler = StandardScaler()
    scaler.fit(train_df[COVARIATES].dropna().values)

    models, fallbacks, coef_rows = {}, {}, []
    for r in STATE_ORDER:
        sub = train_df[train_df["State"] == r]
        model, fallback_counts = fit_origin_model(sub, scaler)
        models[r] = model
        if fallback_counts is not None:
            fallbacks[r] = fallback_counts
            print(f"[{r}] Observasi tidak cukup ({len(sub)} baris) -- pakai frekuensi empiris "
                  f"(Laplace-smoothed), bukan regresi logistik.")
        else:
            boot = bootstrap_se(train_df, r, scaler)
            if boot is not None:
                for _, row in boot.iterrows():
                    coef_rows.append({
                        "State_asal": r, "State_tujuan": row["State_tujuan"],
                        "Covariate": row["Covariate"], "Coef_mean": row["mean"], "Coef_std": row["std"],
                    })

    coef_table = pd.DataFrame(coef_rows)

    # Simpan model + scaler + fallback supaya Script 10 (premium pricing) bisa
    # menghitung peluang transisi SPESIFIK PER PROVINSI berdasarkan anomali
    # iklim aktual provinsi tsb -- bukan cuma matriks baseline (Z=0) yang
    # sama untuk semua provinsi. Ini penting supaya premi benar-benar
    # "climate-responsive" sesuai klaim inti framework, bukan hanya
    # bergantung pada state asal saja.
    with open(OUT_DIR / "fitted_models.pkl", "wb") as f:
        pickle.dump({"models": models, "fallbacks": fallbacks, "scaler": scaler,
                     "covariates": COVARIATES, "state_order": STATE_ORDER}, f)

    P_baseline = build_baseline_matrix(models, fallbacks, scaler)
    Q_baseline, caveats = matrix_to_generator(P_baseline)

    oos = evaluate_oos(models, fallbacks, scaler, test_df)
    all_true, all_pred = oos.pop("_confusion_data")
    oos_df = pd.DataFrame(oos).T

    n_train_trans = train_df.dropna(subset=["State_next"]).groupby(
        ["State", "State_next"]).size().unstack(fill_value=0).reindex(
        index=STATE_ORDER, columns=STATE_ORDER, fill_value=0)
    n_test_trans = test_df.dropna(subset=["State_next"]).groupby(
        ["State", "State_next"]).size().unstack(fill_value=0).reindex(
        index=STATE_ORDER, columns=STATE_ORDER, fill_value=0)

    methodology = pd.DataFrame({
        "Item": [
            "Struktur transisi", "Model", "Kovariat iklim", "Regularisasi",
            "Standard error", "Validasi", "Konversi ke intensitas kontinu",
            "Provinsi held-out (test)", "Catatan matrix logarithm",
        ],
        "Keterangan": [
            "PENUH (4x4, semua arah) -- berbasis bukti: 61 transisi pembaikan vs 48 deteriorasi murni teramati",
            "Multinomial logistic regression per state asal: P(next=s|State=r,Z) = softmax(beta_r^T Z)_s",
            "Anomali bertanda (bukan absolut): Rainfall, Temperature, Humidity, relatif thd rata-rata provinsi sendiri",
            "L2 (ridge), C=1.0 -- menstabilkan estimasi utk transisi jarang (mis. menuju x4, cuma 11 observasi)",
            "Bootstrap (resampling provinsi, B=200) -- bukan Hessian asimtotik, krn sampel kecil",
            "80/20 split PROVINSI (bukan baris) -- model tidak pernah melihat provinsi test saat training",
            "Q = logm(P), valid krn interval observasi seragam 1 tahun (P(1)=exp(Q))",
            str(test_provinces),
            "; ".join(caveats) if caveats else "Tidak ada masalah numerik terdeteksi",
        ],
    })

    out_path = OUT_DIR / "transition_model.xlsx"
    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        coef_table.to_excel(writer, sheet_name="Koefisien_Gamma", index=False)
        P_baseline.to_excel(writer, sheet_name="Baseline_P_1tahun")
        Q_baseline.to_excel(writer, sheet_name="Baseline_Q_intensitas")
        oos_df.to_excel(writer, sheet_name="Validasi_OOS")
        n_train_trans.to_excel(writer, sheet_name="Transisi_Train")
        n_test_trans.to_excel(writer, sheet_name="Transisi_Test")
        methodology.to_excel(writer, sheet_name="Metodologi", index=False)

    plot_coefficients(coef_table)
    plot_baseline_matrix(P_baseline)
    plot_confusion(all_true, all_pred)

    print("\n=== Matriks peluang transisi baseline (Z=0) ===")
    print(P_baseline.round(3).to_string())
    print("\n=== Matriks intensitas kontinu Q (logm(P)) ===")
    print(Q_baseline.round(3).to_string())
    if caveats:
        print("\n[CATATAN NUMERIK]", "; ".join(caveats))
    print("\n=== Validasi out-of-sample (provinsi held-out) ===")
    print(oos_df.round(3).to_string())
    print(f"\nDisimpan ke: {out_path}")
    print(f"Grafik (3 file PNG) disimpan di: {OUT_DIR}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Estimasi model transisi multi-state dgn kovariat iklim (Fase 7)")
    parser.add_argument("--state", required=True, help="Path ke state_dataset.xlsx (Script 08)")
    parser.add_argument("--acri", required=True, help="Path ke acri_dataset.xlsx (Script 07)")
    args = parser.parse_args()
    main(args.state, args.acri)
