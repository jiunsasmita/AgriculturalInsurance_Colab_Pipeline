"""
05_merge_climate_dataset.py

Tujuan
------
Menggabungkan data curah hujan (CHIRPS), suhu & kelembapan (NASA POWER),
dan data pertanian BPS (luas panen, produktivitas, produksi padi) menjadi
satu master dataset penelitian, siap dipakai untuk konstruksi ACRI dan
model multi-state survival.

Cara pakai
----------
    python 05_merge_climate_dataset.py \
        --agriculture /path/ke/master_agriculture_dataset_cleaned.xlsx \
        --agriculture-sheet Panel_Papua_Konsolidasi

Input
-----
data/processed/rainfall_province_2018_2025.xlsx              (Script 03)
data/processed/temperature_humidity_province_2018_2025.xlsx  (Script 04)
--agriculture  (file BPS yang sudah dibersihkan, lihat percakapan sebelumnya)

Output
------
outputs/master_research_dataset_v1.xlsx
    Sheet "Data": Provinsi, Tahun, Luas_Panen_Ha, Produktivitas_KuHa,
                  Produksi_Ton, Rainfall_mm, Temperature_C, Humidity_pct
    Sheet "QC_Merge_Report": ringkasan baris yang tidak lengkap / tidak cocok
"""

import argparse
from pathlib import Path

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
PROCESSED_DIR = BASE_DIR / "data" / "processed"
OUT_DIR = BASE_DIR / "outputs"
OUT_DIR.mkdir(parents=True, exist_ok=True)

# Shapefile provinsi (Script 01) memakai nama resmi "Papua" / "Papua Barat"
# (sebelum pemekaran 2022), sedangkan panel pertanian yang sudah dikonsolidasi
# (master_agriculture_dataset_cleaned.xlsx, sheet Panel_Papua_Konsolidasi)
# memberi label "Papua (konsolidasi)" / "Papua Barat (konsolidasi)" supaya
# jelas bagi pembaca bahwa provinsi hasil pemekaran sudah digabung kembali.
# Tanpa pemetaan ini, kedua nama tidak akan pernah cocok saat di-merge --
# menyebabkan Papua & Papua Barat kehilangan SEMUA data iklim (rainfall,
# suhu, kelembapan) di setiap tahun, karena join berbasis nama persis gagal.
PROVINCE_NAME_FIX = {
    "Papua": "Papua (konsolidasi)",
    "Papua Barat": "Papua Barat (konsolidasi)",
}


def main(agriculture_path: str, agriculture_sheet: str):
    rainfall_path = PROCESSED_DIR / "rainfall_province_2018_2025.xlsx"
    climate_path = PROCESSED_DIR / "temperature_humidity_province_2018_2025.xlsx"

    for p in [rainfall_path, climate_path, Path(agriculture_path)]:
        if not p.exists():
            raise FileNotFoundError(f"File tidak ditemukan: {p}")

    rain = pd.read_excel(rainfall_path)[["Provinsi", "Tahun", "Rainfall_mm"]]
    clim = pd.read_excel(climate_path)[["Provinsi", "Tahun", "Temperature_C", "Humidity_pct"]]
    rain["Provinsi"] = rain["Provinsi"].replace(PROVINCE_NAME_FIX)
    clim["Provinsi"] = clim["Provinsi"].replace(PROVINCE_NAME_FIX)

    agri = pd.read_excel(agriculture_path, sheet_name=agriculture_sheet)
    agri = agri.rename(columns={"Tahun": "Tahun", "Year": "Tahun"})
    agri = agri[["Provinsi", "Tahun", "Luas_Panen_Ha", "Produktivitas_KuHa", "Produksi_Ton"]]

    merged = agri.merge(rain, on=["Provinsi", "Tahun"], how="left")
    merged = merged.merge(clim, on=["Provinsi", "Tahun"], how="left")
    merged = merged.sort_values(["Tahun", "Provinsi"]).reset_index(drop=True)

    # --- QC: baris yang kehilangan salah satu variabel iklim setelah merge ---
    missing_mask = merged[["Rainfall_mm", "Temperature_C", "Humidity_pct"]].isna().any(axis=1)
    qc = merged.loc[missing_mask, ["Provinsi", "Tahun", "Rainfall_mm", "Temperature_C", "Humidity_pct"]]

    out_path = OUT_DIR / "master_research_dataset_v1.xlsx"
    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        merged.to_excel(writer, sheet_name="Data", index=False)
        qc.to_excel(writer, sheet_name="QC_Merge_Report", index=False)

    print(f"Total baris master dataset : {len(merged)}")
    print(f"Baris dengan data iklim hilang setelah merge : {len(qc)}")
    if len(qc) > 0:
        # Bedakan dua pola: provinsi yang KEHILANGAN SEMUA variabel iklim
        # (biasanya nama tidak cocok / provinsi gagal total di Script 03/04)
        # vs provinsi yang hanya kehilangan SEBAGIAN (mis. NASA POWER gagal
        # tapi CHIRPS berhasil untuk provinsi tsb).
        all_missing = qc[qc[["Rainfall_mm", "Temperature_C", "Humidity_pct"]].isna().all(axis=1)]
        partial_missing = qc.drop(all_missing.index)

        if not all_missing.empty:
            provs = sorted(all_missing["Provinsi"].unique())
            print(f"\n[SEMUA variabel iklim hilang] {len(provs)} provinsi: {provs}")
            print(
                "  -> Kemungkinan nama provinsi tidak cocok antara shapefile dan data BPS,"
                " atau provinsi ini gagal total di Script 02/03/04 (cek log saat itu)."
            )
        if not partial_missing.empty:
            provs = sorted(partial_missing["Provinsi"].unique())
            print(f"\n[SEBAGIAN variabel iklim hilang] {len(provs)} provinsi: {provs}")
            print(
                "  -> Kemungkinan salah satu sumber (CHIRPS atau NASA POWER) gagal untuk"
                " provinsi ini di tahun tertentu, tapi sumber lain berhasil."
                " Jalankan ulang Script 02/04 untuk provinsi ini (yang sudah ada di cache akan dilewati)."
            )
        print()
        print(qc.to_string(index=False))
    print(f"\nDisimpan ke: {out_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Gabungkan data iklim + pertanian menjadi master dataset")
    parser.add_argument("--agriculture", required=True, help="Path ke master_agriculture_dataset_cleaned.xlsx")
    parser.add_argument(
        "--agriculture-sheet",
        default="Panel_Papua_Konsolidasi",
        help="Nama sheet di file pertanian (default: Panel_Papua_Konsolidasi, panel seimbang 35 provinsi)",
    )
    args = parser.parse_args()
    main(args.agriculture, args.agriculture_sheet)
