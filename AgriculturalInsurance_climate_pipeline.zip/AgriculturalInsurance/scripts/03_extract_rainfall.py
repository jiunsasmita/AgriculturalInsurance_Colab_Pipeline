"""
03_extract_rainfall.py

Tujuan
------
Menghitung rata-rata curah hujan tahunan per provinsi menggunakan zonal
statistics (bukan centroid): setiap piksel raster CHIRPS yang berada di
dalam poligon provinsi dirata-rata.

Alur:
    Province Polygon (dari Script 01)
        -> CHIRPS Raster tahunan (dari Script 02)
        -> Zonal Statistics (rasterstats)
        -> Mean Rainfall per provinsi per tahun

Cara pakai
----------
    python 03_extract_rainfall.py --start 2018 --end 2025

Input
-----
data/shapefile/provinces_clean.geojson   (dari Script 01)
data/raw/chirps/chirps-v2.0.<year>.tif   (dari Script 02)

Output
------
data/processed/rainfall_province_2018_2025.xlsx
    Kolom: Provinsi, Tahun, Rainfall_mm
"""

import argparse
from pathlib import Path

import geopandas as gpd
import pandas as pd
from rasterstats import zonal_stats

BASE_DIR = Path(__file__).resolve().parent.parent
SHAPEFILE = BASE_DIR / "data" / "shapefile" / "provinces_clean.geojson"
RASTER_DIR = BASE_DIR / "data" / "raw" / "chirps"
OUT_DIR = BASE_DIR / "data" / "processed"
OUT_DIR.mkdir(parents=True, exist_ok=True)


def extract_year(gdf: gpd.GeoDataFrame, year: int) -> pd.DataFrame:
    raster_path = RASTER_DIR / f"chirps-v2.0.{year}.tif"
    if not raster_path.exists():
        raise FileNotFoundError(
            f"Raster tidak ditemukan: {raster_path}. Jalankan dulu "
            f"02_download_chirps.py --start {year} --end {year}"
        )

    # CHIRPS memakai -9999 sebagai nodata (mis. area lautan pada raster global)
    stats = zonal_stats(
        gdf,
        str(raster_path),
        stats=["mean", "count"],
        nodata=-9999,
        geojson_out=False,
    )

    rows = []
    for prov, stat in zip(gdf["Provinsi"], stats):
        if stat["mean"] is None:
            print(
                f"  [PERINGATAN] {prov} ({year}): tidak ada piksel valid "
                f"(count={stat['count']}). Cek apakah poligon berpotongan dengan raster."
            )
        rows.append(
            {
                "Provinsi": prov,
                "Tahun": year,
                "Rainfall_mm": round(stat["mean"], 2) if stat["mean"] is not None else None,
                "n_pixel": stat["count"],
            }
        )
    return pd.DataFrame(rows)


def main(start: int, end: int):
    if not SHAPEFILE.exists():
        raise FileNotFoundError(
            f"{SHAPEFILE} belum ada. Jalankan dulu 01_prepare_boundary.py"
        )
    gdf = gpd.read_file(SHAPEFILE)
    print(f"Provinsi dimuat: {len(gdf)}")

    all_years = []
    for year in range(start, end + 1):
        print(f"\nMemproses tahun {year} ...")
        df_year = extract_year(gdf, year)
        all_years.append(df_year)

    result = pd.concat(all_years, ignore_index=True)
    result = result.sort_values(["Tahun", "Provinsi"]).reset_index(drop=True)

    out_path = OUT_DIR / "rainfall_province_2018_2025.xlsx"
    result.to_excel(out_path, index=False)

    n_missing = result["Rainfall_mm"].isna().sum()
    print(f"\nSelesai. {len(result)} baris disimpan ke {out_path}")
    if n_missing:
        print(f"[PERINGATAN] {n_missing} baris tanpa nilai (cek log di atas).")
    print(result.head(10).to_string(index=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Zonal statistics curah hujan per provinsi")
    parser.add_argument("--start", type=int, default=2018)
    parser.add_argument("--end", type=int, default=2025)
    args = parser.parse_args()
    main(args.start, args.end)
