"""
utils.py
Fungsi bantu bersama untuk seluruh pipeline iklim.
"""

import re
import unicodedata

# Nama provinsi resmi sesuai dataset BPS yang sudah dibersihkan
# (lihat master_agriculture_dataset_cleaned.xlsx, sheet Panel_Papua_Konsolidasi)
BPS_PROVINCE_NAMES = [
    "Aceh", "Sumatera Utara", "Sumatera Barat", "Riau", "Jambi",
    "Sumatera Selatan", "Bengkulu", "Lampung", "Kepulauan Bangka Belitung",
    "Kepulauan Riau", "DKI Jakarta", "Jawa Barat", "Jawa Tengah",
    "DI Yogyakarta", "Jawa Timur", "Banten", "Bali",
    "Nusa Tenggara Barat", "Nusa Tenggara Timur",
    "Kalimantan Barat", "Kalimantan Tengah", "Kalimantan Selatan",
    "Kalimantan Timur", "Kalimantan Utara",
    "Sulawesi Utara", "Sulawesi Tengah", "Sulawesi Selatan",
    "Sulawesi Tenggara", "Gorontalo", "Sulawesi Barat",
    "Maluku", "Maluku Utara",
    "Papua Barat", "Papua",  # konsolidasi -- lihat catatan QC di Panel_Papua_Konsolidasi
]


def normalize_name(name: str) -> str:
    """
    Menstandarkan nama provinsi supaya bisa dicocokkan meskipun ejaan
    di shapefile (BIG/BPS/GADM) sedikit berbeda dari data BPS Anda.
    Contoh: "DI. Yogyakarta" -> "di yogyakarta", "D.K.I Jakarta" -> "dki jakarta"
    """
    if name is None:
        return ""
    s = unicodedata.normalize("NFKD", str(name))
    s = s.lower().strip()
    s = re.sub(r"[.']", "", s)   # "D.I." -> "di" (dot = abbreviation, no space)
    s = re.sub(r"-", " ", s)     # hyphen -> space ("Bangka-Belitung" -> "Bangka Belitung")
    s = re.sub(r"\s+", " ", s)
    return s.strip()


# Alias umum antar sumber shapefile (BIG / BPS / GADM) -> nama baku BPS
PROVINCE_ALIASES = {
    "di yogyakarta": "DI Yogyakarta",
    "daerah istimewa yogyakarta": "DI Yogyakarta",
    "yogyakarta": "DI Yogyakarta",
    "dki jakarta": "DKI Jakarta",
    "jakarta raya": "DKI Jakarta",
    "kepulauan bangka belitung": "Kepulauan Bangka Belitung",
    "bangka belitung": "Kepulauan Bangka Belitung",
    "kepulauan riau": "Kepulauan Riau",
    "nusatenggara barat": "Nusa Tenggara Barat",
    "nusa tenggara barat": "Nusa Tenggara Barat",
    "nusa tenggara timur": "Nusa Tenggara Timur",
    "papua barat": "Papua Barat",
    "papua barat daya": "Papua Barat",       # hasil pemekaran -> konsolidasi
    "papua": "Papua",
    "papua selatan": "Papua",                # hasil pemekaran -> konsolidasi
    "papua tengah": "Papua",                 # hasil pemekaran -> konsolidasi
    "papua pegunungan": "Papua",             # hasil pemekaran -> konsolidasi
}


def match_province(raw_name: str):
    """
    Mengembalikan nama provinsi baku (sesuai BPS_PROVINCE_NAMES) untuk
    sebuah nama mentah dari shapefile, atau None jika tidak ditemukan
    kecocokan. Dipakai supaya join antara shapefile dan data iklim
    tidak gagal karena perbedaan ejaan/kapitalisasi.
    """
    norm = normalize_name(raw_name)
    if norm in PROVINCE_ALIASES:
        return PROVINCE_ALIASES[norm]
    for official in BPS_PROVINCE_NAMES:
        if normalize_name(official) == norm:
            return official
    return None
