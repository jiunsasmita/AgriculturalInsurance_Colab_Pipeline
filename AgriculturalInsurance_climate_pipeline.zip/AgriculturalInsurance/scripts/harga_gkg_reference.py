"""
harga_gkg_reference.py

Referensi harga Gabah Kering Giling (GKG) tingkat petani, Rp/kg, per tahun.

Sumber
------
2018-2024 : BPS -- "Rata-rata Harga Gabah Bulanan Menurut Kualitas, Komponen
             Mutu dan HPP di Tingkat Petani, 2018-2024"
             (https://www.bps.go.id/en/statistics-table/2/MTAzNCMy/...)
             Dihitung sebagai rata-rata aritmatik 12 bulan tiap tahun.
2025        : BELUM ADA angka resmi BPS tahunan saat modul ini ditulis.
             Dipakai nilai 2024 (Rp 7.320,48/kg) sebagai pendekatan
             konservatif, atas keputusan peneliti -- BUKAN estimasi pasar.
             Ganti nilai ini begitu BPS merilis angka resmi 2025.
"""

GKG_PRICE_RP_PER_KG = {
    2018: 5501.24,
    2019: 5463.46,
    2020: 5567.25,
    2021: 5061.87,
    2022: 5491.54,
    2023: 6761.92,
    2024: 7320.48,
    2025: 7320.48,  # nilai 2024 dipakai ulang -- data resmi 2025 belum rilis
}

SOURCE_NOTE = (
    "2018-2024: BPS, Rata-rata Harga Gabah Bulanan Menurut Kualitas, Komponen "
    "Mutu dan HPP di Tingkat Petani (rata-rata 12 bulan, kualitas GKG). "
    "2025: nilai 2024 dipakai ulang karena angka resmi BPS 2025 belum rilis "
    "saat penelitian ini dilakukan (keputusan konservatif peneliti)."
)
