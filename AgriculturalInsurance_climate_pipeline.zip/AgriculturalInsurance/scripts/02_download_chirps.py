"""
02_download_chirps.py

Tujuan
------
Mengunduh raster curah hujan tahunan CHIRPS v2.0 (global, resolusi ~5.5km/0.05
derajat) langsung dari server CHC UCSB, tanpa Google Earth Engine. Setiap file
berisi TOTAL curah hujan setahun (mm) per piksel di seluruh dunia.

Sumber data (akses publik, tidak perlu akun/API key):
    Annual : https://data.chc.ucsb.edu/products/CHIRPS-2.0/global_annual/tifs/chirps-v2.0.<year>.tif
    Bulanan: https://data.chc.ucsb.edu/products/CHIRPS-2.0/global_monthly/tifs/chirps-v2.0.<year>.<bulan>.tif.gz

Catatan format
--------------
Produk TAHUNAN disimpan sebagai .tif polos (tidak di-gzip).
Produk BULANAN disimpan sebagai .tif.gz (gzip).

Kenapa ada fallback ke data bulanan
------------------------------------
Sejak Januari 2025, CHC mulai bertransisi ke CHIRPS v3, dan produk agregat
TAHUNAN v2 untuk tahun-tahun terbaru (mis. 2025) kadang belum/tidak lagi
dihitung ulang oleh CHC -- meski data harian/bulanan v2 tetap tersedia.
Kalau file tahunan tidak ditemukan (404), script ini otomatis mengunduh
12 file bulanan tahun tsb dan MENJUMLAHKANNYA sendiri jadi total tahunan
(curah hujan tahunan = jumlah 12 bulan, bukan rata-rata), lalu menyimpannya
dengan nama file yang sama supaya Script 03 tidak perlu tahu bedanya.

Cara pakai
----------
    python 02_download_chirps.py --start 2018 --end 2025

Output
------
data/raw/chirps/chirps-v2.0.<year>.tif
    Satu file per tahun. Kalau dihasilkan dari penjumlahan bulanan (bukan
    file agregat resmi), akan ada file penanda kosong
    data/raw/chirps/chirps-v2.0.<year>.tif.FROM_MONTHLY_SUM
    supaya Anda tahu provenance-nya saat menulis metodologi.

Catatan jaringan
-----------------
Script ini butuh koneksi internet ke data.chc.ucsb.edu. Jika Anda menjalankan
di lingkungan dengan firewall/whitelist domain (mis. sandbox korporat), pastikan
domain tersebut diizinkan, atau unduh manual lalu taruh di data/raw/chirps/.
CHC UCSB juga menyediakan akses via FTP (ftp://ftp.chc.ucsb.edu/pub/org/chc/...)
sebagai alternatif jika HTTPS diblokir/dibatasi rate-nya; jika --start/--end
tetap gagal setelah perbaikan ini, coba jalankan dengan --use-ftp.
"""

import argparse
import gzip
import shutil
import sys
from pathlib import Path

import numpy as np
import rasterio
import requests

ANNUAL_BASE = "https://data.chc.ucsb.edu/products/CHIRPS-2.0/global_annual/tifs"
ANNUAL_BASE_FTP = "ftp://ftp.chc.ucsb.edu/pub/org/chc/products/CHIRPS-2.0/global_annual/tifs"
MONTHLY_BASE = "https://data.chc.ucsb.edu/products/CHIRPS-2.0/global_monthly/tifs"
MONTHLY_BASE_FTP = "ftp://ftp.chc.ucsb.edu/pub/org/chc/products/CHIRPS-2.0/global_monthly/tifs"

OUT_DIR = Path(__file__).resolve().parent.parent / "data" / "raw" / "chirps"
OUT_DIR.mkdir(parents=True, exist_ok=True)
TMP_MONTHLY_DIR = OUT_DIR / "_monthly_tmp"

NODATA = -9999.0


def _download_raw(url: str, dest: Path, label: str) -> bool:
    """Unduh satu file mentah ke `dest`. True kalau sukses, False kalau gagal."""
    try:
        with requests.get(url, stream=True, timeout=120) as r:
            r.raise_for_status()
            total = int(r.headers.get("content-length", 0))
            downloaded = 0
            with open(dest, "wb") as f:
                for chunk in r.iter_content(chunk_size=1024 * 1024):
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total:
                        pct = downloaded / total * 100
                        print(f"\r  {label}: {downloaded/1e6:,.1f}/{total/1e6:,.1f} MB ({pct:.0f}%)", end="")
            print()
        return True
    except requests.exceptions.RequestException as e:
        print(f"  [ERROR] {label}: {e}")
        if dest.exists():
            dest.unlink()
        return False


def try_download_annual(year: int, use_ftp: bool) -> Path | None:
    out_path = OUT_DIR / f"chirps-v2.0.{year}.tif"
    tmp_path = out_path.with_suffix(".tif.part")
    base = ANNUAL_BASE_FTP if use_ftp else ANNUAL_BASE
    url = f"{base}/chirps-v2.0.{year}.tif"

    print(f"[{year}] Mencoba file tahunan resmi: {url}")
    ok = _download_raw(url, tmp_path, f"{year} (tahunan)")
    if not ok:
        return None
    tmp_path.rename(out_path)
    marker = out_path.with_suffix(out_path.suffix + ".FROM_MONTHLY_SUM")
    if marker.exists():
        marker.unlink()
    print(f"[{year}] Selesai (file resmi) -> {out_path}")
    return out_path


def try_build_from_monthly(year: int, use_ftp: bool) -> Path | None:
    print(f"[{year}] File tahunan tidak ditemukan. Mencoba membangun dari 12 file bulanan ...")
    TMP_MONTHLY_DIR.mkdir(parents=True, exist_ok=True)
    base = MONTHLY_BASE_FTP if use_ftp else MONTHLY_BASE

    monthly_paths = []
    for month in range(1, 13):
        mm = f"{month:02d}"
        gz_path = TMP_MONTHLY_DIR / f"chirps-v2.0.{year}.{mm}.tif.gz"
        tif_path = TMP_MONTHLY_DIR / f"chirps-v2.0.{year}.{mm}.tif"
        if tif_path.exists():
            monthly_paths.append(tif_path)
            continue

        url = f"{base}/chirps-v2.0.{year}.{mm}.tif.gz"
        ok = _download_raw(url, gz_path, f"{year}-{mm}")
        if not ok:
            print(f"[{year}] [ERROR] Bulan {mm} gagal diunduh, tidak bisa membangun total tahunan lengkap.")
            return None

        with gzip.open(gz_path, "rb") as f_in, open(tif_path, "wb") as f_out:
            shutil.copyfileobj(f_in, f_out)
        gz_path.unlink()
        monthly_paths.append(tif_path)

    print(f"[{year}] 12 file bulanan lengkap. Menjumlahkan ...")
    with rasterio.open(monthly_paths[0]) as src0:
        profile = src0.profile
        total = np.zeros((src0.height, src0.width), dtype="float64")
        valid_count = np.zeros((src0.height, src0.width), dtype="int32")

    for p in monthly_paths:
        with rasterio.open(p) as src:
            band = src.read(1).astype("float64")
            valid = band != NODATA
            total[valid] += band[valid]
            valid_count += valid.astype("int32")

    # piksel dianggap valid hanya jika SEMUA 12 bulan punya data;
    # kalau ada bulan yang nodata di suatu piksel, piksel itu jadi nodata
    # (konsisten dengan cara file agregat resmi CHIRPS menandai area tanpa data)
    result = np.where(valid_count == 12, total, NODATA).astype("float32")

    out_path = OUT_DIR / f"chirps-v2.0.{year}.tif"
    profile.update(dtype="float32", nodata=NODATA, compress="lzw")
    with rasterio.open(out_path, "w", **profile) as dst:
        dst.write(result, 1)

    marker = out_path.with_suffix(out_path.suffix + ".FROM_MONTHLY_SUM")
    marker.touch()

    for p in monthly_paths:
        p.unlink()

    print(f"[{year}] Selesai (dibangun dari 12 bulan) -> {out_path}")
    print(f"[{year}] [CATATAN] File ini disintesis dari jumlah 12 raster bulanan, bukan produk "
          f"agregat resmi CHIRPS. Ditandai dengan file '{marker.name}'.")
    return out_path


def download_year(year: int, force: bool = False, use_ftp: bool = False) -> Path | None:
    out_path = OUT_DIR / f"chirps-v2.0.{year}.tif"
    if out_path.exists() and not force:
        print(f"[{year}] sudah ada, dilewati ({out_path.name}). Pakai --force untuk unduh ulang.")
        return out_path

    result = try_download_annual(year, use_ftp)
    if result is not None:
        return result

    return try_build_from_monthly(year, use_ftp)


def main(start: int, end: int, force: bool, use_ftp: bool):
    ok, failed = [], []
    for year in range(start, end + 1):
        result = download_year(year, force=force, use_ftp=use_ftp)
        (ok if result else failed).append(year)

    if TMP_MONTHLY_DIR.exists() and not any(TMP_MONTHLY_DIR.iterdir()):
        TMP_MONTHLY_DIR.rmdir()

    print("\n=== Ringkasan ===")
    print(f"Berhasil : {ok}")
    if failed:
        print(f"Gagal    : {failed}  (jalankan ulang script ini, yang sudah ada akan dilewati)")
        if not use_ftp:
            print("Coba juga jalankan dengan --use-ftp jika HTTPS terus gagal.")
        sys.exit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Unduh raster tahunan CHIRPS (dengan fallback ke jumlah bulanan)")
    parser.add_argument("--start", type=int, default=2018)
    parser.add_argument("--end", type=int, default=2025)
    parser.add_argument("--force", action="store_true", help="Unduh ulang meski file sudah ada")
    parser.add_argument("--use-ftp", action="store_true", help="Pakai FTP alih-alih HTTPS (jika HTTPS gagal/diblokir)")
    args = parser.parse_args()
    main(args.start, args.end, args.force, args.use_ftp)
