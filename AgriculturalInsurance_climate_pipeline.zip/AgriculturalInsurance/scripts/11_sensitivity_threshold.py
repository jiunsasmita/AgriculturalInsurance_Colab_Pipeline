"""
11_sensitivity_threshold.py

Tujuan
------
Fase 6-8 (Sensitivity Analysis): menguji seberapa sensitif distribusi
state, tabel transisi, dan premi terhadap pilihan threshold klasifikasi
state (Reviewer #2 poin 6: "A sensitivity analysis should also show how
estimated transitions and premiums change under alternative threshold
sets").

Koreksi penting (dilaporkan apa adanya, bukan disembunyikan)
-----------------------------------------------------------------------
Threshold yang dipakai di Script 08 (-0.5/-1.0/-1.5 SD) BUKAN persis
threshold asli McKee et al. (1993) untuk SPI, yang sebenarnya adalah
-1.0/-1.5/-2.0 SD (moderate/severe/extreme drought). Analisis ini menguji
KEDUANYA, plus satu varian berbasis persentil (90/95/99%), dan
menunjukkan bahwa:

  - Threshold McKee asli (-1.0/-1.5/-2.0) menghasilkan x4 HANYA 1 observasi
    dari 272 -- terlalu sedikit untuk estimasi model transisi yang andal.
  - Threshold persentil (90/95/99%) menghasilkan x4 = 0 observasi --
    sama sekali tidak bisa dipakai.
  - Threshold yang dipakai di pipeline ini (-0.5/-1.0/-1.5, lebih longgar
    dari McKee asli) dipilih SECARA SADAR sebagai penyesuaian praktis
    supaya keempat state punya observasi yang cukup untuk diestimasi --
    bukan kesalahan yang tidak disadari.

Selain itu, untuk menguji STABILITAS di sekitar threshold yang dipakai,
analisis ini juga menggeser ketiga cutoff secara bersamaan (+/- 0.25 SD)
dan melihat apakah distribusi state & ranking premi antar-provinsi tetap
stabil pada rentang yang secara empiris layak (x4 >= MIN_OBS_X4).

Cara pakai
----------
    python 11_sensitivity_threshold.py --input /path/ke/master_research_dataset_v1.xlsx \
                                        --acri /path/ke/acri_dataset.xlsx

Output (di outputs/sensitivity/)
------------------------------------
sensitivity_report.xlsx
    Sheet "Distribusi_State_per_Threshold" : jumlah observasi tiap state, tiap threshold set
    Sheet "Ranking_Korelasi"                 : korelasi Spearman ranking premi antar threshold set
    Sheet "Premi_per_Threshold"              : premi tiap provinsi, tiap threshold set (yang layak)
    Sheet "Metodologi"
01_distribusi_per_threshold.png
02_stabilitas_ranking_premi.png
"""

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy.stats import spearmanr
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

BASE_DIR = Path(__file__).resolve().parent.parent
OUT_DIR = BASE_DIR / "outputs" / "sensitivity"
OUT_DIR.mkdir(parents=True, exist_ok=True)

STATE_ORDER = ["x1", "x2", "x3", "x4"]
COVARIATES = ["Anomali_Rainfall", "Anomali_Temperature", "Anomali_Humidity"]
MIN_OBS_X4 = 5  # di bawah ini, threshold dianggap tidak layak untuk estimasi model
GKG_PRICE_2025 = 7320.48  # sama dengan Script 10, nilai 2024 dipakai ulang

# Threshold set utama yang dibandingkan
THRESHOLD_SETS = {
    "Dipakai_pipeline (-0.5/-1.0/-1.5)": (-0.5, -1.0, -1.5),
    "McKee_asli_1993 (-1.0/-1.5/-2.0)": (-1.0, -1.5, -2.0),
    "Persentil_90_95_99 (-1.28/-1.65/-2.33)": (-1.28, -1.65, -2.33),
    "Shift_lebih_longgar (-0.25/-0.75/-1.25)": (-0.25, -0.75, -1.25),
    "Shift_lebih_ketat (-0.75/-1.25/-1.75)": (-0.75, -1.25, -1.75),
}

sns.set_style("whitegrid")
plt.rcParams["font.size"] = 10
plt.rcParams["figure.dpi"] = 150


def classify(z, t1, t2, t3):
    if z >= t1:
        return "x1"
    elif z >= t2:
        return "x2"
    elif z >= t3:
        return "x3"
    return "x4"


def compute_states_for_threshold(df, t1, t2, t3):
    df = df.copy()
    grp = df.groupby("Provinsi")["Produktivitas_KuHa"]
    mean_i = grp.transform("mean")
    std_i = grp.transform("std").replace(0, np.nan)
    df["Z"] = ((df["Produktivitas_KuHa"] - mean_i) / std_i).fillna(0)
    df["State"] = df["Z"].apply(lambda z: classify(z, t1, t2, t3))
    return df


def fit_and_predict_premium(df):
    """Reproduksi ringkas alur Script 09+10: fit model transisi, hitung loss matrix & premi."""
    df = df.sort_values(["Provinsi", "Tahun"]).copy()
    df["State_next"] = df.groupby("Provinsi")["State"].shift(-1)

    scaler = StandardScaler()
    scaler.fit(df[COVARIATES].dropna().values)

    models = {}
    for r in STATE_ORDER:
        sub = df[df["State"] == r].dropna(subset=["State_next"])
        if len(sub) < 8 or sub["State_next"].nunique() < 2:
            models[r] = None
            continue
        X = scaler.transform(sub[COVARIATES].values)
        y = sub["State_next"].values
        m = LogisticRegression(C=1.0, max_iter=2000, random_state=42)
        m.fit(X, y)
        models[r] = m

    # loss matrix
    mean_i = df.groupby("Provinsi")["Produktivitas_KuHa"].transform("mean")
    df["Shortfall_KuHa"] = (mean_i - df["Produktivitas_KuHa"]).clip(lower=0)
    loss_by_state = df.groupby("State")["Shortfall_KuHa"].mean().reindex(STATE_ORDER, fill_value=0)
    L = (loss_by_state * 100 * GKG_PRICE_2025).values

    last_year = df["Tahun"].max()
    latest = df[df["Tahun"] == last_year].set_index("Provinsi")

    rows = []
    for prov, row in latest.iterrows():
        r0 = row["State"]
        z = scaler.transform(row[COVARIATES].values.reshape(1, -1))
        probs = np.zeros(len(STATE_ORDER))
        model = models.get(r0)
        if model is not None:
            proba = model.predict_proba(z)[0]
            for cls, p in zip(model.classes_, proba):
                probs[STATE_ORDER.index(cls)] = p
        else:
            probs[STATE_ORDER.index(r0)] = 1.0
        e_loss = float(np.dot(probs, L))
        rows.append({"Provinsi": prov, "Expected_Loss_Rp_per_Ha": e_loss})

    return pd.DataFrame(rows)


def main(input_path: str, acri_path: str):
    base = pd.read_excel(input_path, sheet_name="Data")
    acri = pd.read_excel(acri_path, sheet_name="ACRI")[["Provinsi", "Tahun"] + COVARIATES]
    df = base.merge(acri, on=["Provinsi", "Tahun"], how="inner")

    dist_rows = []
    premium_by_set = {}
    feasible_sets = []

    for name, (t1, t2, t3) in THRESHOLD_SETS.items():
        df_s = compute_states_for_threshold(df, t1, t2, t3)
        counts = df_s["State"].value_counts().reindex(STATE_ORDER, fill_value=0)
        dist_rows.append({"Threshold_set": name, **counts.to_dict(), "Total": counts.sum()})

        n_x4 = counts["x4"]
        if n_x4 >= MIN_OBS_X4:
            feasible_sets.append(name)
            premium_by_set[name] = fit_and_predict_premium(df_s)
        else:
            print(f"[{name}] x4 cuma {n_x4} observasi (< {MIN_OBS_X4}) -- "
                  f"TIDAK LAYAK untuk estimasi model, dilewati dari perbandingan premi.")

    dist_df = pd.DataFrame(dist_rows)

    # --- Korelasi Spearman ranking premi antar threshold set yang layak ---
    corr_rows = []
    ref_name = feasible_sets[0]
    ref_premium = premium_by_set[ref_name].set_index("Provinsi")["Expected_Loss_Rp_per_Ha"]
    for name in feasible_sets:
        cur = premium_by_set[name].set_index("Provinsi")["Expected_Loss_Rp_per_Ha"]
        common = ref_premium.index.intersection(cur.index)
        rho, pval = spearmanr(ref_premium[common], cur[common])
        corr_rows.append({"Threshold_set": name, "Spearman_rho_vs_baseline": round(rho, 3),
                           "p_value": round(pval, 4), "n_provinsi": len(common)})
    corr_df = pd.DataFrame(corr_rows)

    # --- Gabungkan premi semua set layak jadi satu tabel lebar ---
    premium_wide = None
    for name, pdf in premium_by_set.items():
        pdf = pdf.rename(columns={"Expected_Loss_Rp_per_Ha": name}).set_index("Provinsi")
        premium_wide = pdf if premium_wide is None else premium_wide.join(pdf, how="outer")
    premium_wide = premium_wide.round(0)

    methodology = pd.DataFrame({
        "Item": ["Threshold pipeline", "Threshold McKee asli", "Temuan utama",
                 "Kriteria kelayakan", "Metode korelasi"],
        "Keterangan": [
            "-0.5/-1.0/-1.5 SD -- dipilih agar semua state (termasuk x4) punya observasi cukup",
            "-1.0/-1.5/-2.0 SD (McKee et al. 1993) -- menghasilkan x4 hanya 1 observasi dari 272, "
            "terlalu sedikit untuk estimasi model yang andal",
            "Threshold pipeline adalah penyesuaian SADAR dari konvensi asli, didorong oleh "
            "keterbatasan data (granularitas provinsi-tahun), bukan kesalahan tidak disadari",
            f"Threshold dianggap layak untuk estimasi model kalau x4 >= {MIN_OBS_X4} observasi",
            "Spearman rank correlation antara ranking Expected Loss provinsi, dibandingkan "
            "terhadap threshold pipeline sebagai baseline",
        ],
    })

    out_path = OUT_DIR / "sensitivity_report.xlsx"
    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        dist_df.to_excel(writer, sheet_name="Distribusi_State_per_Threshold", index=False)
        corr_df.to_excel(writer, sheet_name="Ranking_Korelasi", index=False)
        premium_wide.to_excel(writer, sheet_name="Premi_per_Threshold")
        methodology.to_excel(writer, sheet_name="Metodologi", index=False)

    # --- Plot 1: distribusi state per threshold set ---
    fig, ax = plt.subplots(figsize=(9, 5))
    x = np.arange(len(dist_df))
    width = 0.2
    colors = ["#199e70", "#e8b339", "#d95926", "#a11d1d"]
    for i, s in enumerate(STATE_ORDER):
        ax.bar(x + i * width, dist_df[s], width, label=s, color=colors[i])
    ax.set_xticks(x + 1.5 * width)
    ax.set_xticklabels(dist_df["Threshold_set"], rotation=20, ha="right", fontsize=8)
    ax.set_ylabel("Jumlah observasi")
    ax.set_title("Distribusi state di bawah berbagai pilihan threshold")
    ax.legend()
    fig.tight_layout()
    fig.savefig(OUT_DIR / "01_distribusi_per_threshold.png")
    plt.close(fig)

    # --- Plot 2: stabilitas ranking premi (scatter vs baseline) ---
    n_feasible = len(feasible_sets)
    fig, axes = plt.subplots(1, max(1, n_feasible - 1), figsize=(5 * max(1, n_feasible - 1), 4.5))
    if n_feasible <= 2:
        axes = [axes]
    for i, name in enumerate([n for n in feasible_sets if n != ref_name]):
        ax = axes[i]
        common = ref_premium.index.intersection(premium_by_set[name].set_index("Provinsi").index)
        x_vals = ref_premium[common] / 1e6
        y_vals = premium_by_set[name].set_index("Provinsi").loc[common, "Expected_Loss_Rp_per_Ha"] / 1e6
        ax.scatter(x_vals, y_vals, alpha=0.7, color="#2a78d6")
        lims = [min(x_vals.min(), y_vals.min()), max(x_vals.max(), y_vals.max())]
        ax.plot(lims, lims, "--", color="gray", linewidth=1)
        rho = corr_df.loc[corr_df["Threshold_set"] == name, "Spearman_rho_vs_baseline"].values[0]
        ax.set_xlabel(f"Expected Loss -- {ref_name}\n(juta Rp/ha)")
        ax.set_ylabel(f"Expected Loss -- {name}\n(juta Rp/ha)")
        ax.set_title(f"rho = {rho:.3f}")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "02_stabilitas_ranking_premi.png")
    plt.close(fig)

    print("=== Distribusi state per threshold set ===")
    print(dist_df.to_string(index=False))
    print("\n=== Korelasi ranking premi (Spearman, vs baseline) ===")
    print(corr_df.to_string(index=False))
    print(f"\nDisimpan ke: {out_path}")
    print(f"Grafik (2 file PNG) disimpan di: {OUT_DIR}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Sensitivity analysis threshold state (Fase 6-8)")
    parser.add_argument("--input", required=True, help="Path ke master_research_dataset_v1.xlsx")
    parser.add_argument("--acri", required=True, help="Path ke acri_dataset.xlsx")
    args = parser.parse_args()
    main(args.input, args.acri)
