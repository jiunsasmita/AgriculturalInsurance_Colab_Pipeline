"""
04_download_nasa_power.py

Tujuan
------
Mengambil suhu (T2M) dan kelembapan relatif (RH2M) bulanan dari NASA POWER
untuk tiap provinsi, lalu menghitung rata-rata tahunan per provinsi.

Dua batasan penting dari NASA POWER Regional API (baru diketahui setelah
percobaan pertama gagal dengan error 422 di SEMUA provinsi):

1. **Luas area maksimum per request adalah 4,5 x 4,5 derajat** (~100 titik
   grid). Banyak provinsi Indonesia (Papua, Riau, Sulawesi Selatan, dll.)
   lebih besar dari itu. Solusi: bounding box provinsi dipecah jadi beberapa
   "ubin" (tile) berukuran <=4,0 derajat, di-request satu-satu, lalu semua
   titik grid hasilnya digabung sebelum di-spatial-join ke poligon provinsi.

2. **Request regional hanya boleh 1 parameter sekaligus** (beda dari
   endpoint "point" yang boleh banyak parameter). Solusi: T2M dan RH2M
   diminta lewat request terpisah, lalu digabung berdasarkan titik
   koordinat + tahun yang sama.

Kenapa pendekatan zonal-nya sedikit berbeda dari CHIRPS
----------------------------------------------------------
CHIRPS beresolusi ~0.05 derajat (~5.5 km) sehingga satu provinsi berisi
ratusan/ribuan piksel -> zonal statistics raster (rasterstats) sangat pas.
NASA POWER native resolution ~0.5 derajat (~55 km), jauh lebih kasar --
sebuah provinsi kecil (mis. DKI Jakarta, Bali) mungkin hanya berisi 1-4 titik
grid. Karena itu kita membangun titik-titik grid dari seluruh ubin, lalu
merata-ratakan HANYA titik yang jatuh di dalam poligon provinsi (spatial
join, bukan bounding box, dan bukan satu titik/centroid).

Cara pakai
----------
    python 04_download_nasa_power.py --start 2018 --end 2025

Input
-----
data/shapefile/provinces_clean.geojson (dari Script 01)

Output
------
data/processed/temperature_humidity_province_2018_2025.xlsx
    Kolom: Provinsi, Tahun, Temperature_C, Humidity_pct, n_grid_points

Catatan jaringan
-----------------
Butuh akses ke power.larc.nasa.gov (API publik, tidak perlu API key untuk
endpoint ini). Jika lingkungan Anda membatasi domain, jalankan script ini
di luar sandbox (Colab / laptop).
"""

import argparse
import json
import time
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import requests
from shapely.geometry import Point

BASE_DIR = Path(__file__).resolve().parent.parent
SHAPEFILE = BASE_DIR / "data" / "shapefile" / "provinces_clean.geojson"
OUT_DIR = BASE_DIR / "data" / "processed"
CACHE_DIR = BASE_DIR / "data" / "climate" / "nasa_power_cache"
OUT_DIR.mkdir(parents=True, exist_ok=True)
CACHE_DIR.mkdir(parents=True, exist_ok=True)

POWER_URL = "https://power.larc.nasa.gov/api/temporal/monthly/regional"
PARAMETERS = ["T2M", "RH2M"]
BUFFER_DEG = 0.5          # ~55km, kira-kira 1 sel grid NASA POWER
TARGET_TILE_DEG = 4.0     # ukuran ubin yang diusahakan (bukan batas keras)
MIN_TILE_DEG = 2.1        # BATAS RESMI NASA POWER: request regional ditolak
                          # (HTTP 422) kalau rentang lat ATAU lon < 2 derajat.
                          # Dipakai 2.1 (bukan pas 2.0) sebagai margin aman --
                          # DI Yogyakarta yang bbox-nya pas dilebarkan tepat
                          # ke 2.00 derajat MASIH ditolak server, kemungkinan
                          # karena pengecekannya "lebih besar dari 2", bukan
                          # "lebih besar sama dengan 2". Margin 0.1 derajat
                          # (~11km) menghindari kasus tepat di batas ini.


def _split_axis(lo: float, hi: float, target: float = TARGET_TILE_DEG,
                 min_size: float = MIN_TILE_DEG):
    """
    Membagi rentang [lo, hi] jadi beberapa segmen, dengan jaminan SETIAP
    segmen >= min_size derajat (termasuk segmen sisa di ujung -- inilah
    yang gagal di versi sebelumnya, karena pembagian rakus/greedy bisa
    menyisakan potongan terakhir yang lebih kecil dari batas minimum).
    """
    length = hi - lo
    if length < min_size:
        # Rentang provinsi (setelah buffer) masih lebih kecil dari batas
        # minimum -- lebarkan simetris supaya tetap valid untuk API.
        pad = (min_size - length) / 2
        lo, hi = lo - pad, hi + pad
        length = hi - lo

    n = max(1, round(length / target))
    while n > 1 and length / n < min_size:
        n -= 1
    seg = length / n
    points = [lo + i * seg for i in range(n + 1)]
    return list(zip(points[:-1], points[1:]))


def make_tiles(minx, miny, maxx, maxy):
    """Pecah bounding box jadi ubin-ubin, masing-masing dijamin >= 2 derajat
    di kedua sisi (syarat resmi NASA POWER Regional API)."""
    lon_segments = _split_axis(minx, maxx)
    lat_segments = _split_axis(miny, maxy)
    return [
        (x0, y0, x1, y1)
        for x0, x1 in lon_segments
        for y0, y1 in lat_segments
    ]


def fetch_tile_param(prov: str, param: str, tile_idx: int,
                      minx, miny, maxx, maxy, start_year: int, end_year: int) -> dict | None:
    safe_prov = prov.replace(" ", "_")
    cache_file = CACHE_DIR / f"{safe_prov}_{param}_tile{tile_idx}_{start_year}_{end_year}.json"
    if cache_file.exists():
        with open(cache_file) as f:
            cached = json.load(f)
        if cached.get("features"):
            return cached
        # Cache lama dari run sebelumnya (sebelum perbaikan ini) bisa berisi
        # "features": [] yang ter-simpan secara keliru sebagai "sukses".
        # Buang cache basi ini dan coba unduh ulang, jangan dipercaya begitu saja.
        print(f"  [{prov}/{param}/ubin{tile_idx}] cache lama kosong terdeteksi, dihapus & dicoba ulang.")
        cache_file.unlink()

    # Coba community="AG" dulu (relevan untuk agrikultur), lalu "RE" sebagai
    # fallback -- semua contoh resmi endpoint REGIONAL yang berhasil kami
    # temukan di dokumentasi NASA POWER memakai community RE/SB, bukan AG,
    # jadi ada kemungkinan AG tidak didukung penuh di endpoint regional.
    for community in ("AG", "RE"):
        params = {
            "parameters": param,   # HANYA satu parameter per request regional
            "community": community,
            "longitude-min": round(minx, 2),
            "longitude-max": round(maxx, 2),
            "latitude-min": round(miny, 2),
            "latitude-max": round(maxy, 2),
            "start": f"{start_year}",
            "end": f"{end_year}",
            "format": "JSON",
        }
        payload = _try_fetch(prov, param, tile_idx, community, params, cache_file)
        if payload is not None:
            return payload
    return None


def _try_fetch(prov, param, tile_idx, community, params, cache_file):
    for attempt in range(3):
        try:
            r = requests.get(POWER_URL, params=params, timeout=180)
            if 400 <= r.status_code < 500:
                # Error klien (validasi parameter dll) -- BUKAN error transient,
                # mengulang dengan parameter yang sama tidak akan membantu.
                # Tampilkan pesan asli dari server, lalu langsung menyerah
                # supaya fetch_tile_param bisa coba community lain.
                try:
                    body = r.json()
                except ValueError:
                    body = r.text[:500]
                print(f"  [{prov}/{param}/ubin{tile_idx}/community={community}] "
                      f"gagal (HTTP {r.status_code}), tidak diulang. Pesan server: {body}")
                print(f"  URL: {r.url}")
                return None
            if r.status_code >= 500:
                print(f"  [{prov}/{param}/ubin{tile_idx}/community={community}] "
                      f"percobaan {attempt+1}/3: server error {r.status_code}, mencoba lagi ...")
                time.sleep(5)
                continue
            payload = r.json()

            # PENTING: server bisa merespons 200 OK tapi dengan "features": []
            # (tidak ada titik grid dikembalikan) -- ini BUKAN keberhasilan.
            # Kalau ini di-cache begitu saja, saat script dijalankan ulang untuk
            # memperbaiki provinsi yang gagal, ia akan membaca cache kosong ini
            # dan TIDAK PERNAH mencoba community fallback lagi -- gagal secara
            # permanen dan tanpa pesan error yang terlihat. Jadi payload kosong
            # diperlakukan sebagai kegagalan (tidak di-cache, lanjut ke community
            # berikutnya), bukan sebagai sukses.
            if not payload.get("features"):
                print(f"  [{prov}/{param}/ubin{tile_idx}/community={community}] "
                      f"HTTP 200 tapi 'features' kosong (tidak ada titik grid dikembalikan) -- "
                      f"dianggap gagal, tidak di-cache.")
                print(f"  URL: {r.url}")
                return None

            with open(cache_file, "w") as f:
                json.dump(payload, f)
            return payload
        except requests.exceptions.RequestException as e:
            print(f"  [{prov}/{param}/ubin{tile_idx}/community={community}] percobaan {attempt+1}/3 gagal: {e}")
            time.sleep(5)
    return None


def parse_single_param_response(payload: dict, param: str) -> pd.DataFrame:
    """
    Setiap feature = satu titik grid. properties.parameter[param] berisi
    dict {"YYYYMM": value}, termasuk kunci ringkasan non-bulanan seperti
    "YYYY13" yang kita abaikan.

    Koordinat dibulatkan ke 4 desimal (~11m) supaya titik grid yang sama
    dari request T2M dan RH2M (dua request API terpisah) tetap bisa
    dicocokkan persis saat digabung, meskipun ada perbedaan representasi
    floating-point sekecil apa pun antar respons server.
    """
    rows = []
    for feat in payload.get("features", []):
        lon, lat = feat["geometry"]["coordinates"][:2]
        lon, lat = round(lon, 4), round(lat, 4)
        values_by_month = feat["properties"]["parameter"].get(param, {})
        years = {}
        for key, val in values_by_month.items():
            if len(key) == 6 and key[4:] != "13":
                yr = int(key[:4])
                years.setdefault(yr, []).append(val)
        for yr, vals in years.items():
            rows.append({"lon": lon, "lat": lat, "Tahun": yr, param: np.mean(vals)})
    return pd.DataFrame(rows)


def fetch_province_grid(prov: str, geom, start_year: int, end_year: int) -> pd.DataFrame:
    minx, miny, maxx, maxy = geom.bounds
    minx, miny = minx - BUFFER_DEG, miny - BUFFER_DEG
    maxx, maxy = maxx + BUFFER_DEG, maxy + BUFFER_DEG
    tiles = make_tiles(minx, miny, maxx, maxy)

    print(f"\n{prov}: bbox {minx:.2f},{miny:.2f},{maxx:.2f},{maxy:.2f} "
          f"-> {len(tiles)} ubin x {len(PARAMETERS)} parameter = "
          f"{len(tiles) * len(PARAMETERS)} request")

    param_dfs = {p: [] for p in PARAMETERS}
    for tile_idx, (tminx, tminy, tmaxx, tmaxy) in enumerate(tiles):
        for param in PARAMETERS:
            payload = fetch_tile_param(prov, param, tile_idx, tminx, tminy, tmaxx, tmaxy,
                                        start_year, end_year)
            if payload is None:
                print(f"  [PERINGATAN] {prov}/{param}/ubin{tile_idx} gagal total, dilewati.")
                continue
            df = parse_single_param_response(payload, param)
            if not df.empty:
                param_dfs[param].append(df)

    if not param_dfs["T2M"] or not param_dfs["RH2M"]:
        print(f"  [{prov}] T2M atau RH2M gagal total di semua ubin (T2M: {len(param_dfs['T2M'])} "
              f"ubin berhasil, RH2M: {len(param_dfs['RH2M'])} ubin berhasil).")
        return pd.DataFrame()

    t2m = pd.concat(param_dfs["T2M"], ignore_index=True)
    rh2m = pd.concat(param_dfs["RH2M"], ignore_index=True)

    # gabungkan berdasarkan titik grid + tahun yang sama
    merged = pd.merge(t2m, rh2m, on=["lon", "lat", "Tahun"], how="inner")

    if merged.empty:
        # T2M dan RH2M sama-sama punya data, tapi tidak ada titik yang cocok
        # persis -- kemungkinan grid pointnya sedikit berbeda antar request.
        # Fallback: cocokkan tiap titik T2M ke titik RH2M TERDEKAT (bukan
        # exact match), asal jaraknya sangat kecil (<0.01 derajat, ~1km).
        print(f"  [{prov}] [PERINGATAN] T2M ({len(t2m)} titik) dan RH2M ({len(rh2m)} titik) "
              f"tidak ada yang cocok persis pada koordinat bulat. Mencoba pencocokan "
              f"titik terdekat sebagai fallback ...")
        rows = []
        for _, trow in t2m.iterrows():
            dist = np.hypot(rh2m["lon"] - trow["lon"], rh2m["lat"] - trow["lat"])
            same_year = rh2m["Tahun"] == trow["Tahun"]
            candidates = rh2m[same_year]
            if candidates.empty:
                continue
            idx = dist[same_year].idxmin()
            if dist[idx] < 0.01:
                rows.append({
                    "lon": trow["lon"], "lat": trow["lat"], "Tahun": trow["Tahun"],
                    "T2M": trow["T2M"], "RH2M": rh2m.loc[idx, "RH2M"],
                })
        merged = pd.DataFrame(rows)
        if not merged.empty:
            print(f"  [{prov}] Pencocokan titik terdekat berhasil: {len(merged)} baris.")
        else:
            print(f"  [{prov}] [ERROR] Tetap tidak ada titik yang cocok bahkan dengan toleransi jarak.")

    return merged


def main(start: int, end: int):
    if not SHAPEFILE.exists():
        raise FileNotFoundError(f"{SHAPEFILE} belum ada. Jalankan dulu 01_prepare_boundary.py")
    gdf = gpd.read_file(SHAPEFILE)
    print(f"Provinsi dimuat: {len(gdf)}")

    all_rows = []
    for _, row in gdf.iterrows():
        prov = row["Provinsi"]
        grid_df = fetch_province_grid(prov, row.geometry, start, end)
        if grid_df.empty:
            print(f"  [PERINGATAN] Tidak ada data untuk {prov}, dilewati.")
            continue

        points = gpd.GeoDataFrame(
            grid_df,
            geometry=[Point(xy) for xy in zip(grid_df["lon"], grid_df["lat"])],
            crs="EPSG:4326",
        )
        inside = gpd.sjoin(points, gdf[gdf["Provinsi"] == prov][["Provinsi", "geometry"]],
                            how="inner", predicate="within")

        if inside.empty:
            print(f"  [PERINGATAN] Tidak ada titik grid di dalam poligon {prov}; "
                  f"memakai seluruh titik dalam bbox+buffer sebagai fallback.")
            inside = points.copy()
            inside["Provinsi"] = prov

        yearly = (
            inside.groupby("Tahun")
            .agg(Temperature_C=("T2M", "mean"), Humidity_pct=("RH2M", "mean"),
                 n_grid_points=("T2M", "count"))
            .reset_index()
        )
        yearly["Provinsi"] = prov
        all_rows.append(yearly)

    if not all_rows:
        raise RuntimeError("Tidak ada data yang berhasil diambil untuk provinsi manapun.")

    result = pd.concat(all_rows, ignore_index=True)
    result = result[["Provinsi", "Tahun", "Temperature_C", "Humidity_pct", "n_grid_points"]]
    result = result.sort_values(["Tahun", "Provinsi"]).reset_index(drop=True)

    out_path = OUT_DIR / "temperature_humidity_province_2018_2025.xlsx"
    result.to_excel(out_path, index=False)
    print(f"\nSelesai. {len(result)} baris disimpan ke {out_path}")
    print(result.head(10).to_string(index=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ambil suhu & kelembapan NASA POWER per provinsi")
    parser.add_argument("--start", type=int, default=2018)
    parser.add_argument("--end", type=int, default=2025)
    args = parser.parse_args()
    main(args.start, args.end)
