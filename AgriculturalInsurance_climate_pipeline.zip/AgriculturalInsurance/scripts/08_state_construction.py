"""
08_state_construction.py

Tujuan
------
Fase 6: mengklasifikasikan kondisi tanaman tiap provinsi-tahun ke dalam
4 state (x1 Normal, x2 Moderate Stress, x3 Severe Deterioration,
x4 Crop Collapse), lalu melaporkan tabel transisi teramati yang jadi
input untuk estimasi model multi-state di Fase 7.

Keputusan metodologis (PENTING -- baca sebelum dipakai di manuskrip)
-----------------------------------------------------------------------
Percobaan awal memakai R(t) = (Y_max - Y(t))/Y_max dengan beberapa pilihan
Y_max GAGAL menghasilkan sebaran state yang wajar:

  - Y_max = maksimum historis provinsi sendiri -> x4 TIDAK PERNAH terjadi
    (0 dari 272 observasi), x3 cuma 9 observasi. Deviasi dari performa
    terbaik provinsi sendiri dalam 8 tahun secara alami kecil.

  - Y_max = potensi genetik varietas unggul nasional (~9,1 ton/ha atau 91
    ku/ha, dari rilis varietas Balitbangtan/Kementan seperti Inpari 48 Blas
    dan Mantap) -> KEBALIKANNYA: 271 dari 272 observasi jatuh ke x3/x4,
    x1 (normal) nyaris tidak pernah muncul. Ini karena potensi hasil hasil
    uji varietas di stasiun penelitian (kondisi optimal terkendali) secara
    agronomis mengukur hal yang BERBEDA dari performa petani riil di
    lapangan -- kesenjangan itu ("yield gap") berasal dari faktor
    teknologi/sosial-ekonomi yang PERMANEN, bukan deteriorasi akibat iklim.
    Memakainya sebagai Y_max mencampur dua fenomena yang berbeda.

Solusi yang dipakai di script ini: KLASIFIKASI BERBASIS Z-SCORE (SPI-style)
-----------------------------------------------------------------------
Mengikuti konvensi Standardized Precipitation Index (SPI; McKee, Doesken,
& Kleist, 1993, "The relationship of drought frequency and duration to
time scales", 8th Conference on Applied Climatology) yang telah luas
dipakai dalam literatur risiko iklim/kekeringan pertanian:

    Z_it = (Produktivitas_it - rata2_provinsi_i) / std_provinsi_i

Z dihitung relatif terhadap rata-rata & std historis PROVINSI ITU SENDIRI
(2018-2025) -- supaya index murni mengukur penyimpangan dari kondisi
normal provinsi tsb, tidak tercampur perbedaan teknologi/struktural antar
provinsi (yang menjadi masalah di pendekatan Y_max absolut).

Ambang batas (arah dibalik dari SPI karena kita mengukur DEFISIT
produktivitas, bukan surplus curah hujan):

    Z >= -0.5              -> x1  Normal
    -1.0 <= Z < -0.5        -> x2  Moderate Stress
    -1.5 <= Z < -1.0        -> x3  Severe Deterioration
    Z < -1.5                -> x4  Crop Collapse

Thresholds ini BUKAN dipilih dari distribusi data kita sendiri (yang akan
membuatnya sirkular) -- melainkan konvensi baku dari literatur eksternal,
sehingga dapat disitasi sebagai justifikasi (menjawab Reviewer #2 poin 6).

CATATAN JUJUR: transisi ke/dari x4 tetap tipis (11 dari 272 observasi
mengalami x4). Ini dilaporkan apa adanya di tabel transisi output --
kemungkinan perlu parameter sharing/regularisasi saat estimasi model
transisi di Fase 7 (lihat Reviewer #2 poin 10).

Cara pakai
----------
    python 08_state_construction.py --input /path/ke/master_research_dataset_v1.xlsx \
                                     --acri /path/ke/acri_dataset.xlsx

Output (di outputs/state_construction/)
------------------------------------------
state_dataset.xlsx
    Sheet "Data"              : Provinsi, Tahun, Z, State, + variabel ACRI (kalau disediakan)
    Sheet "Transisi"           : tabel transisi teramati (baris=state asal, kolom=state tujuan)
    Sheet "Distribusi_State"   : jumlah & persentase observasi per state
    Sheet "Metodologi"         : ringkasan formula, threshold, dan sitasi
01_distribusi_state.png
02_transisi_heatmap.png
03_state_over_time.png
"""

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

BASE_DIR = Path(__file__).resolve().parent.parent
OUT_DIR = BASE_DIR / "outputs" / "state_construction"
OUT_DIR.mkdir(parents=True, exist_ok=True)

STATE_ORDER = ["x1", "x2", "x3", "x4"]
STATE_LABELS = {
    "x1": "x1 Normal",
    "x2": "x2 Moderate Stress",
    "x3": "x3 Severe Deterioration",
    "x4": "x4 Crop Collapse",
}

sns.set_style("whitegrid")
plt.rcParams["font.size"] = 10
plt.rcParams["figure.dpi"] = 150


def classify_state(z: float) -> str:
    if z >= -0.5:
        return "x1"
    elif z >= -1.0:
        return "x2"
    elif z >= -1.5:
        return "x3"
    else:
        return "x4"


def compute_states(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    grp = df.groupby("Provinsi")["Produktivitas_KuHa"]
    mean_i = grp.transform("mean")
    std_i = grp.transform("std").replace(0, np.nan)
    df["Z"] = (df["Produktivitas_KuHa"] - mean_i) / std_i
    df["Z"] = df["Z"].fillna(0)
    df["State"] = df["Z"].apply(classify_state)
    return df


def transition_table(df: pd.DataFrame) -> pd.DataFrame:
    df = df.sort_values(["Provinsi", "Tahun"]).copy()
    df["State_next"] = df.groupby("Provinsi")["State"].shift(-1)
    trans = df.dropna(subset=["State_next"])
    table = (
        trans.groupby(["State", "State_next"]).size()
        .unstack(fill_value=0)
        .reindex(index=STATE_ORDER, columns=STATE_ORDER, fill_value=0)
    )
    return table


def state_distribution(df: pd.DataFrame) -> pd.DataFrame:
    counts = df["State"].value_counts().reindex(STATE_ORDER, fill_value=0)
    pct = (counts / counts.sum() * 100).round(1)
    return pd.DataFrame({"Jumlah": counts, "Persentase (%)": pct})


def plot_distribution(dist: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(6, 4))
    labels = [STATE_LABELS[s] for s in dist.index]
    colors = ["#199e70", "#e8b339", "#d95926", "#a11d1d"]
    ax.bar(labels, dist["Jumlah"], color=colors)
    for i, v in enumerate(dist["Jumlah"]):
        ax.text(i, v + 2, str(v), ha="center")
    ax.set_ylabel("Jumlah observasi (provinsi-tahun)")
    ax.set_title("Distribusi state kondisi tanaman (2018-2025)")
    plt.xticks(rotation=15, ha="right")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "01_distribusi_state.png")
    plt.close(fig)


def plot_transition_heatmap(table: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(5.5, 5))
    sns.heatmap(table, annot=True, fmt="d", cmap="YlOrRd", ax=ax,
                cbar_kws={"label": "Jumlah transisi teramati"})
    ax.set_xlabel("State tujuan")
    ax.set_ylabel("State asal")
    ax.set_title("Tabel transisi teramati antar-tahun")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "02_transisi_heatmap.png")
    plt.close(fig)


def plot_state_over_time(df: pd.DataFrame):
    pivot = df.groupby(["Tahun", "State"]).size().unstack(fill_value=0).reindex(columns=STATE_ORDER, fill_value=0)
    fig, ax = plt.subplots(figsize=(7, 4))
    colors = ["#199e70", "#e8b339", "#d95926", "#a11d1d"]
    pivot.plot(kind="bar", stacked=True, ax=ax, color=colors)
    ax.set_xlabel("Tahun")
    ax.set_ylabel("Jumlah provinsi")
    ax.set_title("Komposisi state tiap tahun (34 provinsi)")
    ax.legend([STATE_LABELS[s] for s in STATE_ORDER], fontsize=8)
    plt.xticks(rotation=0)
    fig.tight_layout()
    fig.savefig(OUT_DIR / "03_state_over_time.png")
    plt.close(fig)


def main(input_path: str, acri_path: str | None):
    df = pd.read_excel(input_path, sheet_name="Data")
    result = compute_states(df)

    if acri_path:
        acri = pd.read_excel(acri_path, sheet_name="ACRI")
        acri_cols = ["Provinsi", "Tahun", "ACRI"] + [c for c in acri.columns if c.endswith("_norm")]
        result = result.merge(acri[acri_cols], on=["Provinsi", "Tahun"], how="left")
        if result["ACRI"].isna().any():
            print(f"[PERINGATAN] {result['ACRI'].isna().sum()} baris tidak punya padanan ACRI.")

    trans = transition_table(result)
    dist = state_distribution(result)

    methodology = pd.DataFrame({
        "Item": ["Formula", "Baseline", "Threshold x1", "Threshold x2", "Threshold x3",
                 "Threshold x4", "Sumber threshold", "Catatan transisi jarang"],
        "Keterangan": [
            "Z_it = (Produktivitas_it - rata2_provinsi_i) / std_provinsi_i",
            "Rata-rata & std historis provinsi itu sendiri (2018-2025), BUKAN rata-rata/potensi nasional",
            "Z >= -0.5",
            "-1.0 <= Z < -0.5",
            "-1.5 <= Z < -1.0",
            "Z < -1.5",
            "McKee, Doesken & Kleist (1993), konvensi Standardized Precipitation Index (SPI), arah dibalik untuk defisit produktivitas",
            f"x4 teramati {int(dist.loc['x4','Jumlah'])} dari {len(result)} observasi -- transisi ke/dari x4 tipis, "
            "pertimbangkan parameter sharing/regularisasi saat estimasi Fase 7",
        ],
    })

    out_path = OUT_DIR / "state_dataset.xlsx"
    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        keep_cols = ["Provinsi", "Tahun", "Produktivitas_KuHa", "Z", "State"]
        if acri_path:
            keep_cols += ["ACRI"]
        result[keep_cols].sort_values(["Tahun", "Provinsi"]).to_excel(
            writer, sheet_name="Data", index=False)
        trans.to_excel(writer, sheet_name="Transisi")
        dist.to_excel(writer, sheet_name="Distribusi_State")
        methodology.to_excel(writer, sheet_name="Metodologi", index=False)

    plot_distribution(dist)
    plot_transition_heatmap(trans)
    plot_state_over_time(result)

    print("=== Distribusi state ===")
    print(dist.to_string())
    print("\n=== Tabel transisi teramati ===")
    print(trans.to_string())
    print(f"\nTotal transisi teramati: {trans.values.sum()}")
    n_x4 = int(dist.loc["x4", "Jumlah"])
    if n_x4 < 20:
        print(f"\n[PERINGATAN] State x4 cuma teramati {n_x4} kali -- estimasi parameter transisi "
              f"terkait x4 di Fase 7 kemungkinan perlu regularisasi/parameter sharing.")
    print(f"\nDisimpan ke: {out_path}")
    print(f"Grafik (3 file PNG) disimpan di: {OUT_DIR}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Konstruksi state kondisi tanaman (Fase 6)")
    parser.add_argument("--input", required=True, help="Path ke master_research_dataset_v1.xlsx")
    parser.add_argument("--acri", default=None, help="Path ke acri_dataset.xlsx (opsional, dari Fase 5)")
    args = parser.parse_args()
    main(args.input, args.acri)
