"""
10_expected_loss_premium.py

Tujuan
------
Fase 8: menghitung expected loss dan premi asuransi climate-responsive per
provinsi, berdasarkan model transisi (Fase 7) dan harga referensi GKG resmi
BPS. Ini menjawab kritik Reviewer #2 poin 15-18 soal loss matrix tanpa
sumber, initial state tidak didefinisikan, dan struktur kontrak yang tidak
jelas.

Keputusan desain (PENTING -- baca sebelum dipakai di manuskrip)
-----------------------------------------------------------------------
1. SUMBER LOSS MATRIX (L_s): dihitung dari data riil, BUKAN angka asumsi.
   Untuk tiap observasi provinsi-tahun, shortfall = rata2_historis_provinsi
   - Produktivitas_aktual (dalam ku/ha, floor di 0 -- kalau produktivitas
   di atas normal, tidak ada shortfall/klaim). Shortfall ini SUDAH
   dinormalisasi per-provinsi (karena dikurangi rata2 provinsi itu sendiri),
   sehingga bisa di-pool lintas provinsi secara adil. L_s = rata-rata
   shortfall (ku/ha) pada semua observasi yang tergolong state s, dikali
   100 (ku->kg) dikali harga referensi GKG (Rp/kg, resmi BPS).

2. HARGA REFERENSI: Rata-rata Harga Gabah Kering Giling (GKG) Bulanan di
   Tingkat Petani, sumber BPS (data/raw/harga_gabah_bps_2018_2024.xlsx),
   2018-2024. Untuk 2025 (belum ada angka resmi tahunan BPS saat pipeline
   ini dibuat), dipakai nilai 2024 sebagai pendekatan konservatif -- lihat
   parameter PRICE_YEAR_FOR_PREMIUM.

3. LOSS BERBASIS STATE AKHIR PERIODE (bukan per-transisi): sesuai keputusan
   desain kontrak (deductible penuh di x1, indemnitas berdasar state di
   akhir periode pertanggungan 1 tahun) -- BUKAN pembayaran berulang tiap
   transisi yang dilalui dalam periode yang sama.

4. INITIAL STATE (r0): state AKTUAL provinsi tsb di tahun observasi
   terakhir (2025) -- bukan distribusi populasi abstrak. Setiap provinsi
   punya r0 sendiri sesuai kondisi riilnya.

5. KLIMAT UNTUK PROYEKSI: anomali iklim TERAKHIR YANG TERAMATI (2025)
   dipakai sebagai proksi kondisi iklim tahun berikutnya -- BUKAN Z=0
   (kondisi rata-rata). Ini yang membuat premi benar-benar "climate-
   responsive" per provinsi, bukan seragam. Keterbatasan: ini mengasumsikan
   kondisi iklim tahun berjalan mirip tahun terakhir -- untuk pricing
   prospektif yang lebih akurat, idealnya pakai proyeksi/skenario iklim,
   bukan observasi historis terakhir (dicatat sebagai limitasi).

6. LOADING FACTOR: prinsip standar deviasi (standard deviation premium
   principle -- Bühlmann, 1970; lihat juga Klugman, Panjer & Willmot,
   "Loss Models", edisi manapun, Bab 5) -- Premium = E[L] + k * SD[L],
   dengan k dikalibrasi ke tingkat keyakinan 95% satu-arah (k=1.645, dari
   tabel distribusi normal standar) -- BUKAN konstanta sembarangan.

7. STRUKTUR KONTRAK: periode pertanggungan 1 tahun (1 musim tanam
   tahunan), basis per hektar lahan panen, tidak ada diskonto (karena
   premi dan periode klaim berada dalam satu tahun yang sama, time value
   of money diabaikan untuk versi pertama ini -- limitasi yang dicatat).

Cara pakai
----------
    python 10_expected_loss_premium.py \
        --state outputs/state_construction/state_dataset.xlsx \
        --acri outputs/acri/acri_dataset.xlsx \
        --transition-script scripts/09_estimate_transition_model.py

Output (di outputs/premium/)
------------------------------
premium_dataset.xlsx
    Sheet "Loss_Matrix"    : L_s per state (ku/ha, Rp/ha)
    Sheet "Premi_Provinsi" : r0, prediksi distribusi state, E[L], SD[L], premi per provinsi
    Sheet "Harga_Referensi": harga GKG tahunan yang dipakai
    Sheet "Metodologi"     : ringkasan keputusan desain (siap salin ke manuskrip)
01_loss_matrix.png
02_premi_per_provinsi.png
"""

import argparse
import importlib.util
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

BASE_DIR = Path(__file__).resolve().parent.parent
OUT_DIR = BASE_DIR / "outputs" / "premium"
OUT_DIR.mkdir(parents=True, exist_ok=True)

STATE_ORDER = ["x1", "x2", "x3", "x4"]
COVARIATES = ["Anomali_Rainfall", "Anomali_Temperature", "Anomali_Humidity"]
Z_CONFIDENCE_95 = 1.645  # loading factor: tingkat keyakinan 95% satu-arah

# Harga referensi GKG resmi BPS (Rp/kg), rata-rata tahunan dari
# data/raw/harga_gabah_bps_2018_2024.xlsx
GKG_PRICE_BY_YEAR = {
    2018: 5501.24, 2019: 5463.46, 2020: 5567.25, 2021: 5061.87,
    2022: 5491.54, 2023: 6761.92, 2024: 7320.48,
    2025: 7320.48,  # belum ada angka resmi tahunan BPS -- pakai nilai 2024 (konservatif)
}
PRICE_YEAR_FOR_PREMIUM = 2025  # harga dipakai untuk premi prospektif

sns.set_style("whitegrid")
plt.rcParams["font.size"] = 10
plt.rcParams["figure.dpi"] = 150


def load_transition_module():
    """Import ulang fungsi-fungsi dari Script 09 supaya konsisten (tidak duplikasi kode)."""
    spec = importlib.util.spec_from_file_location(
        "transition_model", BASE_DIR / "scripts" / "09_estimate_transition_model.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def compute_loss_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """
    Loss matrix L_s (ku/ha) dari shortfall riil per state, di-pool lintas
    provinsi (sudah dinormalisasi via pengurangan rata2 provinsi sendiri).
    """
    df = df.copy()
    mean_i = df.groupby("Provinsi")["Produktivitas_KuHa"].transform("mean")
    df["Shortfall_KuHa"] = (mean_i - df["Produktivitas_KuHa"]).clip(lower=0)

    loss = df.groupby("State")["Shortfall_KuHa"].mean().reindex(STATE_ORDER, fill_value=0)
    loss_df = pd.DataFrame({"Shortfall_KuHa": loss})
    loss_df["Shortfall_Kg_Ha"] = loss_df["Shortfall_KuHa"] * 100
    price = GKG_PRICE_BY_YEAR[PRICE_YEAR_FOR_PREMIUM]
    loss_df["Loss_Rp_per_Ha"] = loss_df["Shortfall_Kg_Ha"] * price
    loss_df["Harga_GKG_dipakai"] = price
    return loss_df


def build_premium_table(df: pd.DataFrame, loss_df: pd.DataFrame, mod) -> pd.DataFrame:
    """Hitung E[L], SD[L], dan premi per provinsi menggunakan state & iklim terakhir teramati."""
    train_df = df.sort_values(["Provinsi", "Tahun"]).copy()
    train_df["State_next"] = train_df.groupby("Provinsi")["State"].shift(-1)

    scaler = mod.StandardScaler()
    scaler.fit(train_df[COVARIATES].dropna().values)

    models = {}
    for r in STATE_ORDER:
        sub = train_df[train_df["State"] == r]
        model, _ = mod.fit_origin_model(sub, scaler)
        models[r] = model

    last_year = df["Tahun"].max()
    latest = df[df["Tahun"] == last_year].set_index("Provinsi")

    L = loss_df["Loss_Rp_per_Ha"].values  # urut sesuai STATE_ORDER

    rows = []
    for prov, row in latest.iterrows():
        r0 = row["State"]
        z = scaler.transform(row[COVARIATES].values.reshape(1, -1))

        probs = np.zeros(len(STATE_ORDER))
        model = models.get(r0)
        if model is not None:
            proba = model.predict_proba(z)[0]
            for cls, p in zip(model.classes_, proba):
                probs[STATE_ORDER.index(cls)] = p
        else:
            probs[STATE_ORDER.index(r0)] = 1.0  # fallback: dianggap tetap di state yg sama

        e_loss = float(np.dot(probs, L))
        var_loss = float(np.dot(probs, (L - e_loss) ** 2))
        sd_loss = np.sqrt(var_loss)
        premium = e_loss + Z_CONFIDENCE_95 * sd_loss

        rows.append({
            "Provinsi": prov,
            "State_awal_r0": r0,
            "Tahun_acuan": int(last_year),
            **{f"P_{s}": probs[i] for i, s in enumerate(STATE_ORDER)},
            "Expected_Loss_Rp_per_Ha": round(e_loss),
            "SD_Loss_Rp_per_Ha": round(sd_loss),
            "Loading_95pct_Rp_per_Ha": round(Z_CONFIDENCE_95 * sd_loss),
            "Premi_Rp_per_Ha": round(premium),
        })

    return pd.DataFrame(rows).sort_values("Premi_Rp_per_Ha", ascending=False)


def plot_loss_matrix(loss_df: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(6, 4))
    colors = ["#199e70", "#e8b339", "#d95926", "#a11d1d"]
    ax.bar(loss_df.index, loss_df["Loss_Rp_per_Ha"] / 1e6, color=colors)
    for i, v in enumerate(loss_df["Loss_Rp_per_Ha"] / 1e6):
        ax.text(i, v + 0.02, f"{v:.2f}", ha="center")
    ax.set_ylabel("Loss (juta Rp/ha)")
    ax.set_title("Loss matrix (L_s) per state -- harga GKG referensi "
                 f"{PRICE_YEAR_FOR_PREMIUM}: Rp{GKG_PRICE_BY_YEAR[PRICE_YEAR_FOR_PREMIUM]:,.0f}/kg")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "01_loss_matrix.png")
    plt.close(fig)


def plot_premium_by_province(premium_df: pd.DataFrame, n: int = 15):
    top = premium_df.head(n)
    fig, ax = plt.subplots(figsize=(7, 6))
    colors = {"x1": "#199e70", "x2": "#e8b339", "x3": "#d95926", "x4": "#a11d1d"}
    bar_colors = [colors[r] for r in top["State_awal_r0"]]
    ax.barh(top["Provinsi"], top["Premi_Rp_per_Ha"] / 1e6, color=bar_colors)
    ax.invert_yaxis()
    ax.set_xlabel("Premi (juta Rp/ha/tahun)")
    ax.set_title(f"{n} provinsi dengan premi tertinggi (warna = state awal r0)")
    handles = [plt.Rectangle((0, 0), 1, 1, color=c) for c in colors.values()]
    ax.legend(handles, colors.keys(), title="r0", loc="lower right")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "02_premi_per_provinsi.png")
    plt.close(fig)


def main(state_path: str, acri_path: str):
    mod = load_transition_module()
    df = mod.load_and_merge(state_path, acri_path)

    # load_and_merge dari Script 09 hanya bawa State, bukan Produktivitas --
    # perlu digabung lagi dengan state_dataset yang punya kolom Produktivitas_KuHa
    state_full = pd.read_excel(state_path, sheet_name="Data")
    df = df.merge(state_full[["Provinsi", "Tahun", "Produktivitas_KuHa"]],
                  on=["Provinsi", "Tahun"], how="left")

    loss_df = compute_loss_matrix(df)
    premium_df = build_premium_table(df, loss_df, mod)

    price_ref = pd.DataFrame({
        "Tahun": list(GKG_PRICE_BY_YEAR.keys()),
        "Harga_GKG_Rp_per_Kg": list(GKG_PRICE_BY_YEAR.values()),
        "Sumber": ["BPS resmi"] * 7 + ["Estimasi (nilai 2024 dipakai ulang)"],
    })

    methodology = pd.DataFrame({
        "Item": [
            "Sumber loss matrix", "Harga referensi", "Basis pembayaran",
            "Initial state (r0)", "Kovariat iklim untuk proyeksi",
            "Loading factor", "Periode & diskonto", "Unit eksposur",
        ],
        "Keterangan": [
            "Shortfall riil (rata2 historis provinsi - produktivitas aktual), di-pool lintas "
            "provinsi setelah dinormalisasi per-provinsi, dikonversi ke Rp via harga GKG resmi BPS",
            f"Rata-rata Harga GKG Bulanan BPS 2018-2024; 2025 pakai nilai 2024 (konservatif, "
            f"belum ada angka resmi tahunan saat pipeline dibuat)",
            "State di AKHIR periode pertanggungan (bukan per-transisi); x1 = deductible penuh, "
            "tidak ada indemnitas",
            "State AKTUAL provinsi di tahun observasi terakhir (2025), per-provinsi -- bukan "
            "distribusi populasi abstrak",
            "Anomali iklim TERAKHIR TERAMATI (2025) per provinsi -- bukan kondisi rata-rata (Z=0). "
            "Limitasi: mengasumsikan kondisi iklim tahun berjalan mirip tahun terakhir",
            "Standard deviation premium principle (Buhlmann 1970; Klugman-Panjer-Willmot Loss "
            "Models): Premium = E[L] + 1.645*SD[L], k=1.645 dari tingkat keyakinan 95% satu-arah",
            "1 tahun (1 musim tanam tahunan), tanpa diskonto (premi & klaim dalam periode yang sama)",
            "Per hektar lahan panen (Rp/ha/tahun)",
        ],
    })

    out_path = OUT_DIR / "premium_dataset.xlsx"
    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        loss_df.to_excel(writer, sheet_name="Loss_Matrix")
        premium_df.to_excel(writer, sheet_name="Premi_Provinsi", index=False)
        price_ref.to_excel(writer, sheet_name="Harga_Referensi", index=False)
        methodology.to_excel(writer, sheet_name="Metodologi", index=False)

    plot_loss_matrix(loss_df)
    plot_premium_by_province(premium_df)

    print("=== Loss Matrix (L_s) ===")
    print(loss_df.round(0).to_string())
    print(f"\n=== Premi per provinsi (harga referensi {PRICE_YEAR_FOR_PREMIUM}: "
          f"Rp{GKG_PRICE_BY_YEAR[PRICE_YEAR_FOR_PREMIUM]:,.0f}/kg) ===")
    print(premium_df[["Provinsi", "State_awal_r0", "Expected_Loss_Rp_per_Ha",
                       "Premi_Rp_per_Ha"]].to_string(index=False))
    print(f"\nDisimpan ke: {out_path}")
    print(f"Grafik (2 file PNG) disimpan di: {OUT_DIR}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Expected loss & premi climate-responsive (Fase 8)")
    parser.add_argument("--state", required=True, help="Path ke state_dataset.xlsx (Script 08)")
    parser.add_argument("--acri", required=True, help="Path ke acri_dataset.xlsx (Script 07)")
    args = parser.parse_args()
    main(args.state, args.acri)
