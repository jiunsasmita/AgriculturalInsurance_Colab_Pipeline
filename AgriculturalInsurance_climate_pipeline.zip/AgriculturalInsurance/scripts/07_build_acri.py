"""
07_build_acri.py

Tujuan
------
Fase 5: membangun Agricultural Climate Risk Index (ACRI) per provinsi per
tahun, mengikuti kerangka normalisasi min-max di artikel Anda (Eq. 1):

    z_tilde_m(t) = (z_m(t) - z_m_min) / (z_m_max - z_m_min)

Keputusan metodologis (PENTING -- baca sebelum dipakai di manuskrip)
-----------------------------------------------------------------------
Artikel Anda menyebut 4 indikator: rainfall anomaly, temperature deviation,
drought severity index, flood occurrence intensity. Pipeline yang sudah
dibangun (Script 02-05) hanya mengumpulkan 3 variabel MENTAH dari CHIRPS/
NASA POWER: Rainfall_mm, Temperature_C, Humidity_pct -- bukan indeks
kekeringan/banjir yang sudah jadi. Karena itu:

1. ANOMALI, bukan level absolut. Untuk tiap provinsi, dihitung deviasi
   relatif terhadap rata-rata historis provinsi itu SENDIRI selama
   2018-2025 (bukan rata-rata nasional) -- karena "curah hujan tinggi"
   untuk Kalimantan Barat (rata-rata ~3.700mm) berbeda makna dengan
   "curah hujan tinggi" untuk NTT (rata-rata ~1.800mm).

        anomaly_it = (nilai_it - rata2_provinsi_i) / std_provinsi_i

2. NILAI ABSOLUT dipakai (bukan nilai bertanda), dengan asumsi deviasi ke
   arah manapun dari kondisi normal meningkatkan risiko -- baik kekeringan
   (anomali negatif) maupun kelebihan air/banjir (anomali positif) sama-sama
   risiko bagi produktivitas. Ini pengganti proxy untuk "drought severity"
   dan "flood occurrence" yang tidak punya data terpisah.

3. BOBOT SAMA RATA (1/3 tiap variabel) sebagai default -- bisa diubah lewat
   --weights kalau Anda punya justifikasi lain (mis. dari expert judgment
   atau hasil sensitivity analysis di artikel Anda).

Kalau Anda TIDAK setuju dengan asumsi di atas (mis. ingin nilai bertanda,
bukan absolut; atau baseline nasional, bukan per-provinsi), skenario itu
mudah diubah -- lihat parameter di fungsi compute_anomalies() dan build_acri().

Cara pakai
----------
    python 07_build_acri.py --input /path/ke/master_research_dataset_v1.xlsx

Output (di outputs/acri/)
--------------------------
acri_dataset.xlsx
    Sheet "ACRI"          : Provinsi, Tahun, ACRI, dan komponen penyusunnya
    Sheet "Metodologi"     : ringkasan formula & asumsi (siap salin ke manuskrip)
01_distribusi_acri.png
02_acri_tren_provinsi_terpilih.png
03_komponen_acri_heatmap.png
"""

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

BASE_DIR = Path(__file__).resolve().parent.parent
OUT_DIR = BASE_DIR / "outputs" / "acri"
OUT_DIR.mkdir(parents=True, exist_ok=True)

CLIMATE_VARS = ["Rainfall_mm", "Temperature_C", "Humidity_pct"]
ANOMALY_COLS = ["Anomali_Rainfall", "Anomali_Temperature", "Anomali_Humidity"]

sns.set_style("whitegrid")
plt.rcParams["font.size"] = 10
plt.rcParams["figure.dpi"] = 150


def compute_anomalies(df: pd.DataFrame) -> pd.DataFrame:
    """
    Anomali standar (z-score) tiap variabel iklim, relatif terhadap rata-rata
    dan std historis PROVINSI ITU SENDIRI (bukan rata-rata nasional).
    """
    df = df.copy()
    for var, col in zip(CLIMATE_VARS, ANOMALY_COLS):
        grp = df.groupby("Provinsi")[var]
        mean_i = grp.transform("mean")
        std_i = grp.transform("std")
        std_i = std_i.replace(0, np.nan)  # jaga-jaga kalau provinsi punya std=0
        df[col] = (df[var] - mean_i) / std_i
        df[col] = df[col].fillna(0)  # provinsi dgn std=0 -> anomali dianggap 0
    return df


def minmax_normalize(series: pd.Series) -> pd.Series:
    """Normalisasi min-max persis Eq.(1) di artikel: (z - z_min) / (z_max - z_min)."""
    z_min, z_max = series.min(), series.max()
    if z_max == z_min:
        return pd.Series(0.0, index=series.index)
    return (series - z_min) / (z_max - z_min)


def build_acri(df: pd.DataFrame, weights: dict) -> pd.DataFrame:
    df = compute_anomalies(df)

    # Nilai absolut anomali -- deviasi ke arah manapun = risiko (lihat
    # penjelasan metodologis di docstring modul ini).
    for col in ANOMALY_COLS:
        df[f"{col}_abs"] = df[col].abs()

    # Normalisasi min-max ke [0,1], dihitung atas SELURUH dataset (272 baris)
    # supaya skala antar provinsi & tahun konsisten -- sesuai Eq.(1) artikel.
    normalized_cols = []
    for col in ANOMALY_COLS:
        norm_col = f"{col}_norm"
        df[norm_col] = minmax_normalize(df[f"{col}_abs"])
        normalized_cols.append(norm_col)

    w = np.array([weights["rainfall"], weights["temperature"], weights["humidity"]])
    assert abs(w.sum() - 1.0) < 1e-6, "Bobot harus berjumlah 1.0"

    df["ACRI"] = (df[normalized_cols].values * w).sum(axis=1)
    return df


def plot_distribution(df: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.hist(df["ACRI"], bins=20, color="#2a78d6", edgecolor="white")
    ax.axvline(df["ACRI"].mean(), color="#d95926", linestyle="--",
               label=f"Rata-rata = {df['ACRI'].mean():.3f}")
    ax.set_xlabel("ACRI")
    ax.set_ylabel("Frekuensi (jumlah provinsi-tahun)")
    ax.set_title("Distribusi Agricultural Climate Risk Index (ACRI)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(OUT_DIR / "01_distribusi_acri.png")
    plt.close(fig)


def plot_trend_selected(df: pd.DataFrame, n: int = 6):
    # Pilih provinsi dengan rata-rata ACRI tertinggi & terendah untuk kontras
    prov_mean = df.groupby("Provinsi")["ACRI"].mean().sort_values()
    selected = list(prov_mean.head(n // 2).index) + list(prov_mean.tail(n // 2).index)

    fig, ax = plt.subplots(figsize=(8, 5))
    for prov in selected:
        sub = df[df["Provinsi"] == prov].sort_values("Tahun")
        ax.plot(sub["Tahun"], sub["ACRI"], marker="o", label=prov, linewidth=1.5)
    ax.set_xlabel("Tahun")
    ax.set_ylabel("ACRI")
    ax.set_title(f"Tren ACRI: {n // 2} provinsi tertinggi & terendah (rata-rata)")
    ax.legend(fontsize=8, loc="upper left", bbox_to_anchor=(1.02, 1))
    fig.tight_layout()
    fig.savefig(OUT_DIR / "02_acri_tren_provinsi_terpilih.png")
    plt.close(fig)


def plot_component_heatmap(df: pd.DataFrame, n: int = 15):
    prov_mean = (
        df.groupby("Provinsi")[["ACRI"] + [f"{c}_norm" for c in ANOMALY_COLS]]
        .mean()
        .sort_values("ACRI", ascending=False)
        .head(n)
    )
    display_df = prov_mean.rename(columns={
        "Anomali_Rainfall_norm": "Rainfall",
        "Anomali_Temperature_norm": "Suhu",
        "Anomali_Humidity_norm": "Kelembapan",
    })[["Rainfall", "Suhu", "Kelembapan", "ACRI"]]

    fig, ax = plt.subplots(figsize=(6, 8))
    sns.heatmap(display_df, annot=True, fmt=".2f", cmap="OrRd", ax=ax,
                cbar_kws={"label": "Nilai ternormalisasi (0-1)"})
    ax.set_title(f"{n} provinsi dengan ACRI tertinggi -- komponen penyusun")
    ax.set_ylabel("")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "03_komponen_acri_heatmap.png")
    plt.close(fig)


def main(input_path: str, w_rain: float, w_temp: float, w_hum: float):
    df = pd.read_excel(input_path, sheet_name="Data")
    weights = {"rainfall": w_rain, "temperature": w_temp, "humidity": w_hum}

    result = build_acri(df, weights)

    keep_cols = (
        ["Provinsi", "Tahun"] + CLIMATE_VARS + ANOMALY_COLS
        + [f"{c}_norm" for c in ANOMALY_COLS] + ["ACRI"]
    )
    result_out = result[keep_cols].sort_values(["Tahun", "Provinsi"]).reset_index(drop=True)

    methodology = pd.DataFrame({
        "Komponen": ["Baseline anomali", "Transformasi", "Normalisasi", "Bobot rainfall",
                     "Bobot suhu", "Bobot kelembapan", "Formula ACRI"],
        "Keterangan": [
            "Rata-rata & std historis provinsi itu sendiri (2018-2025), bukan rata-rata nasional",
            "Nilai absolut anomali (deviasi ke arah manapun = risiko)",
            "Min-max ke [0,1], Eq.(1) artikel: (z - z_min)/(z_max - z_min), dihitung atas seluruh dataset",
            f"{w_rain}",
            f"{w_temp}",
            f"{w_hum}",
            "ACRI = w_rain*Rainfall_norm + w_temp*Temperature_norm + w_hum*Humidity_norm",
        ],
    })

    out_path = OUT_DIR / "acri_dataset.xlsx"
    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        result_out.to_excel(writer, sheet_name="ACRI", index=False)
        methodology.to_excel(writer, sheet_name="Metodologi", index=False)

    plot_distribution(result_out)
    plot_trend_selected(result_out)
    plot_component_heatmap(result_out)

    print(f"ACRI berhasil dihitung untuk {len(result_out)} baris.")
    print(f"Rentang ACRI: {result_out['ACRI'].min():.3f} - {result_out['ACRI'].max():.3f}")
    print(f"Rata-rata ACRI: {result_out['ACRI'].mean():.3f}")
    print("\n5 provinsi-tahun dengan ACRI tertinggi (kondisi iklim paling menyimpang):")
    print(result_out.nlargest(5, "ACRI")[["Provinsi", "Tahun", "ACRI"]].to_string(index=False))
    print("\n5 provinsi-tahun dengan ACRI terendah (kondisi iklim paling normal):")
    print(result_out.nsmallest(5, "ACRI")[["Provinsi", "Tahun", "ACRI"]].to_string(index=False))
    print(f"\nDisimpan ke: {out_path}")
    print(f"Grafik (3 file PNG) disimpan di: {OUT_DIR}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Bangun Agricultural Climate Risk Index (Fase 5)")
    parser.add_argument("--input", required=True,
                         help="Path ke master_research_dataset_v1.xlsx (Script 05)")
    parser.add_argument("--weights", default="0.34,0.33,0.33",
                         help="Bobot rainfall,temperature,humidity (default sama rata, jumlah harus 1.0)")
    args = parser.parse_args()
    w_rain, w_temp, w_hum = (float(x) for x in args.weights.split(","))
    main(args.input, w_rain, w_temp, w_hum)
