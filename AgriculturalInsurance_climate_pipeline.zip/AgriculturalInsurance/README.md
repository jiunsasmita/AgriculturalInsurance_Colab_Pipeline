# Agricultural Insurance — Climate Data Pipeline

Pipeline Python 100% reproducible untuk membangun dataset iklim per provinsi
(curah hujan, suhu, kelembapan) menggunakan **zonal statistics** atas batas
administrasi provinsi — bukan centroid.

```
Province Polygon (Script 01)
        |
        v
CHIRPS Raster (Script 02) ---- Zonal Stats ----> Rainfall_mm (Script 03)
NASA POWER Grid (Script 04) --- Zonal Avg (titik grid dalam polygon)
        |
        v
Master Research Dataset (Script 05)
```

## Kenapa tidak pakai Google Earth Engine

Rencana awal memakai GEE (lebih ringkas, komputasi di server Google). Tapi
pipeline ini sengaja ditulis dengan **download langsung via HTTP + geopandas/
rasterstats**, karena:

1. `ee.Authenticate()` butuh login browser interaktif — tidak bisa dijalankan
   di lingkungan headless/sandbox tanpa GUI.
2. Anda bisa langsung menjalankan seluruh pipeline ini di laptop/Colab tanpa
   perlu setup akun Google Cloud/Earth Engine project.
3. Semua sumber data (CHIRPS, NASA POWER) publik dan gratis, tanpa API key.

Kalau nanti Anda tetap ingin versi GEE (lebih cepat untuk raster besar),
struktur outputnya (kolom Provinsi/Tahun/Rainfall_mm dst.) sengaja dibuat
identik supaya Script 05 tetap bisa dipakai tanpa perubahan.

## Instalasi

```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Langkah menjalankan pipeline

### 1. Siapkan batas provinsi

```bash
# Jalankan tanpa --name-field dulu untuk melihat nama kolom yang tersedia
python scripts/01_prepare_boundary.py --input data/shapefile/RBI_Provinsi.shp

# Lalu jalankan dengan nama kolom yang benar, contoh untuk shapefile BIG:
python scripts/01_prepare_boundary.py --input data/shapefile/RBI_Provinsi.shp --name-field WADMPR

# Untuk GADM level-1:
python scripts/01_prepare_boundary.py --input gadm41_IDN_1.shp --name-field NAME_1
```

Cek `data/shapefile/boundary_validation_report.csv` — pastikan **35 provinsi**
(versi konsolidasi Papua) semuanya cocok. Kalau ada yang hilang/tidak
dikenal, tambahkan alias di `scripts/utils.py` (lihat dict `PROVINCE_ALIASES`).

### 2. Unduh raster CHIRPS

```bash
python scripts/02_download_chirps.py --start 2018 --end 2025
```

~140-160 MB per tahun (global), total ±1.2 GB untuk 8 tahun. Bisa
dihentikan dan dilanjutkan kapan saja — file yang sudah ada otomatis dilewati.

### 3. Zonal statistics curah hujan

```bash
python scripts/03_extract_rainfall.py --start 2018 --end 2025
```

### 4. Suhu & kelembapan (NASA POWER)

```bash
python scripts/04_download_nasa_power.py --start 2018 --end 2025
```

Butuh 1 request API per provinsi (bukan per tahun), jadi ±35 request total.
Hasil di-cache di `data/climate/nasa_power_cache/` supaya tidak perlu unduh
ulang kalau script dijalankan lagi.

### 5. Gabungkan menjadi master dataset

```bash
python scripts/05_merge_climate_dataset.py \
    --agriculture /path/ke/master_agriculture_dataset_cleaned.xlsx \
    --agriculture-sheet Panel_Papua_Konsolidasi
```

Pakai file `master_agriculture_dataset_cleaned.xlsx` yang sudah dibersihkan
(lihat percakapan sebelumnya: nilai Produktivitas 2020 sudah dikoreksi,
provinsi hasil pemekaran Papua sudah dikonsolidasi jadi panel seimbang).

Output akhir: `outputs/master_research_dataset_v1.xlsx`

### 6. Exploratory analysis (Fase 4)

```bash
python scripts/06_exploratory_analysis.py --input outputs/master_research_dataset_v1.xlsx
```

Menghasilkan statistik deskriptif, matriks korelasi, ranking provinsi, dan
4 grafik (tren produktivitas nasional, ranking provinsi, heatmap korelasi,
scatter curah hujan vs produktivitas) di `outputs/eda/`.

## Status pengujian

Setiap script sudah diuji logikanya dengan data sintetis (raster & shapefile
buatan) sebelum diserahkan — termasuk pencocokan nama provinsi dengan alias
("D.I. Yogyakarta" dll.), penggabungan provinsi hasil pemekaran, perhitungan
zonal mean, parsing respons NASA POWER, dan proses merge akhir. **Yang belum
diuji adalah koneksi nyata ke data.chc.ucsb.edu dan power.larc.nasa.gov**,
karena lingkungan tempat script ini ditulis tidak punya akses ke kedua host
tersebut (dibatasi jaringan sandbox). Jalankan Script 02–04 di komputer/Colab
Anda sendiri yang punya akses internet penuh, lalu kabari saya kalau ada
error spesifik dari server — saya bisa bantu debug dari situ.

## Struktur folder

```
AgriculturalInsurance/
├── data/
│   ├── raw/chirps/          <- raster CHIRPS mentah (Script 02)
│   ├── shapefile/           <- batas provinsi bersih (Script 01)
│   ├── climate/              <- cache respons NASA POWER (Script 04)
│   └── processed/            <- rainfall & suhu/kelembapan per provinsi (Script 03, 04)
├── scripts/
│   ├── utils.py               <- pencocokan nama provinsi (dipakai semua script)
│   ├── 01_prepare_boundary.py
│   ├── 02_download_chirps.py
│   ├── 03_extract_rainfall.py
│   ├── 04_download_nasa_power.py
│   ├── 05_merge_climate_dataset.py
│   └── 06_exploratory_analysis.py
├── outputs/                    <- master_research_dataset_v1.xlsx
├── requirements.txt
└── README.md
```
