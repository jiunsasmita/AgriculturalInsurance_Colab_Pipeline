# Sumber Data: Batas Provinsi Indonesia

## File
`provinces_clean.geojson` — 34 provinsi (versi sebelum pemekaran Papua 2022),
sudah distandarkan lewat `01_prepare_boundary.py`:
- CRS: EPSG:4326
- 3 geometri tidak valid diperbaiki otomatis (buffer(0))
- Nama provinsi distandarkan ke penamaan baku BPS (kolom `Provinsi`)
- Semua 34 provinsi cocok 100% dengan data BPS Anda (lihat `boundary_validation_report.csv`)

## Rantai sumber (provenance)

1. **Sumber asli**: Badan Informasi Geospasial (BIG), melalui portal
   geoservice.big.go.id (layanan resmi batas administrasi Indonesia).
2. **Dikemas ulang oleh**: repositori GitHub publik
   `Alf-Anas/batas-administrasi-indonesia` (https://github.com/Alf-Anas/batas-administrasi-indonesia),
   yang mendistribusikan ulang data BIG dalam format SHP/GeoJSON/GPKG untuk
   kemudahan akses (data batas provinsi versi 2020, sebelum pemekaran Papua).
3. **Divalidasi oleh Claude**: dicek validitas geometri, dicocokkan nama
   provinsi, dan disandingkan luas wilayah hasil perhitungan geometri dengan
   angka resmi (mis. Papua ≈317.009 km², DKI Jakarta ≈656,6 km² — keduanya
   sangat dekat dengan angka publikasi BPS/BIG).

## Rekomendasi untuk manuskrip

Untuk kredibilitas maksimal di jurnal Q2, cantumkan sumber sebagai:

> Provincial administrative boundaries were obtained from the Geospatial
> Information Agency of Indonesia (Badan Informasi Geospasial/BIG),
> accessed via geoservice.big.go.id, and redistributed through the public
> repository Alf-Anas/batas-administrasi-indonesia (2023).

**Opsional (lebih kuat lagi):** jika ada waktu sebelum submit, unduh ulang
versi resmi langsung dari geoservice.big.go.id atau tanahair.indonesia.go.id
untuk memastikan tidak ada perubahan dari pihak ketiga yang mendistribusikan
ulang. Berdasarkan pengecekan luas wilayah di atas, kemungkinan besar datanya
identik, tapi mengunduh langsung dari sumber resmi menghindari pertanyaan
reviewer soal provenance data.

## Catatan penting: versi 34 provinsi (bukan 38)

File ini memakai batas **sebelum** pemekaran Papua 2022 (34 provinsi: Papua
dan Papua Barat sebagai wilayah induk, belum terpecah jadi 6). Ini **sengaja**
dipilih supaya konsisten dengan pendekatan konsolidasi yang sudah kita pakai
di `master_agriculture_dataset_cleaned.xlsx` (sheet `Panel_Papua_Konsolidasi`),
sehingga panel data 2018-2025 tetap seimbang (unit spasial sama sepanjang
periode observasi) -- prasyarat penting untuk model multi-state survival.
